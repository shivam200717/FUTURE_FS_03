import React, { useState, useEffect } from 'react';
import { Header, ActiveScreen } from './components/Header';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OvenScheduleScreen } from './components/OvenScheduleScreen';
import { ReservationScreen } from './components/ReservationScreen';
import { CraftStoryScreen } from './components/CraftStoryScreen';
import { OrdersTrackerScreen } from './components/OrdersTrackerScreen';
import { Footer } from './components/Footer';
import { Toast, ToastMessage } from './components/Toast';
import { BAKERY_PRODUCTS } from './data/bakeryData';
import { BakeryProduct, CartItem, OrderRecord, BakeryCategory, ProductAddon, ReservationRequest } from './types/bakery';
import { Search, Flame, ArrowRight, Sparkles, Filter, Clock, Check, Coffee, Wheat } from 'lucide-react';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('boutique');
  const [cart, setCart] = useState<CartItem[]>(() => {
    // Initial sample item for immediate delight
    return [
      {
        product: BAKERY_PRODUCTS[0], // Signature Country Batard
        quantity: 1,
        selectedSlicing: 'thick',
        selectedAddons: [BAKERY_PRODUCTS[0].availableAddons![0]], // Whipped Échiré Butter
      },
    ];
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<BakeryProduct | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  
  // Checkout pass parameters
  const [checkoutPickupSlot, setCheckoutPickupSlot] = useState('08:30 AM - 09:00 AM (Fresh Hearth Pull)');
  const [checkoutDiscount, setCheckoutDiscount] = useState(0);

  // Menu filters
  const [selectedCategory, setSelectedCategory] = useState<BakeryCategory>('all');
  const [selectedDietary, setSelectedDietary] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Orders list initialized with a recent active order
  const [orders, setOrders] = useState<OrderRecord[]>([
    {
      id: 'ord_demo_1',
      orderNumber: 'MM-7824',
      createdAt: '07:45 AM',
      pickupTime: '08:30 AM - 09:00 AM (Fresh Hearth Pull)',
      items: [
        { product: BAKERY_PRODUCTS[1], quantity: 2 }, // 2x Baguettes
        { product: BAKERY_PRODUCTS[2], quantity: 2 }, // 2x Pain au Chocolat
      ],
      subtotal: 20.50,
      discount: 0,
      tax: 1.69,
      total: 22.19,
      customerName: 'Claire Delacroix',
      customerPhone: '+33 6 42 18 90 22',
      customerEmail: 'claire.delacroix@example.com',
      fulfillmentType: 'pickup',
      paymentMethod: 'apple_pay',
      status: 'in_oven',
    },
  ]);

  const addToast = (title: string, description?: string, type: 'success' | 'info' | 'warning' = 'success') => {
    const id = `toast_${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Cart operations
  const handleQuickAdd = (product: BakeryProduct) => {
    setCart((prev) => {
      const existingIdx = prev.findIndex((item) => item.product.id === product.id && !item.selectedAddons?.length);
      if (existingIdx > -1) {
        const next = [...prev];
        next[existingIdx].quantity += 1;
        return next;
      }
      return [...prev, { product, quantity: 1 }];
    });
    addToast(`Added to Bag`, `${product.name} · $${product.price.toFixed(2)}`);
  };

  const handleModalAddToCart = (
    product: BakeryProduct,
    quantity: number,
    slicing?: 'whole' | 'thick' | 'toast',
    addons?: ProductAddon[],
    specialInstructions?: string
  ) => {
    setCart((prev) => [
      ...prev,
      {
        product,
        quantity,
        selectedSlicing: slicing,
        selectedAddons: addons,
        specialInstructions,
      },
    ]);
    addToast(`Added ${quantity}x to Bag`, `${product.name} ${slicing ? `(${slicing} slice)` : ''}`);
  };

  const handleUpdateQuantity = (index: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(index);
      return;
    }
    setCart((prev) => {
      const next = [...prev];
      next[index].quantity = quantity;
      return next;
    });
  };

  const handleRemoveCartItem = (index: number) => {
    const item = cart[index];
    setCart((prev) => prev.filter((_, i) => i !== index));
    if (item) {
      addToast(`Removed from Bag`, item.product.name, 'info');
    }
  };

  const handleProceedToCheckout = (
    appliedPromo?: { code: string; discountAmount: number },
    pickupSlot?: string
  ) => {
    if (appliedPromo) {
      setCheckoutDiscount(appliedPromo.discountAmount);
    } else {
      setCheckoutDiscount(0);
    }
    if (pickupSlot) {
      setCheckoutPickupSlot(pickupSlot);
    }
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderCompleted = (newOrder: OrderRecord) => {
    setOrders((prev) => [newOrder, ...prev]);
    setCart([]); // Clear cart
    addToast('Order Placed!', `Bake queue #${newOrder.orderNumber} confirmed.`, 'success');
  };

  const handleReservationConfirmed = (res: ReservationRequest) => {
    addToast('Table Reserved', `${res.guests} guests · ${res.date} at ${res.time}`, 'success');
  };

  const handleOvenBatchNotify = (batchName: string, time: string) => {
    addToast('SMS Alert Activated', `We will notify you at ${time} when ${batchName} leaves the stone hearth!`, 'info');
  };

  // Cart totals calculation
  const cartItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => {
    const addonsCost = (item.selectedAddons || []).reduce((sum, a) => sum + a.price, 0);
    return acc + (item.product.price + addonsCost) * item.quantity;
  }, 0);

  // Filtered products for Menu Screen
  const filteredProducts = BAKERY_PRODUCTS.filter((product) => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesDietary =
      selectedDietary === 'all' ||
      product.dietaryTags.some((tag) => tag.toLowerCase().includes(selectedDietary.toLowerCase()));
    const matchesSearch =
      searchQuery.trim() === '' ||
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.frenchName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.flourBlend.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesDietary && matchesSearch;
  });

  const categories: { id: BakeryCategory; label: string }[] = [
    { id: 'all', label: 'All Bakery Creations' },
    { id: 'sourdough', label: 'Sourdough Loaves' },
    { id: 'pastries', label: 'Morning Viennoiserie' },
    { id: 'savory', label: 'Savory & Tartines' },
    { id: 'coffee', label: 'Specialty Roastery' },
    { id: 'pantry', label: 'Artisan Pantry Jars' },
  ];

  return (
    <div className="min-h-screen bg-[#FAF6F0] text-[#2C221E] flex flex-col font-sans selection:bg-[#C46D1E]/20 selection:text-[#934B00]">
      
      {/* Toast Notification Container */}
      <Toast toasts={toasts} onDismiss={removeToast} />

      {/* Top Bar Navigation (Strict 3-zone contract) */}
      <Header
        activeScreen={activeScreen}
        onNavigate={setActiveScreen}
        cartCount={cartItemCount}
        cartSubtotal={cartSubtotal}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Main Content View Switcher */}
      <main className="flex-1">
        
        {/* ========================================================
            SCREEN 1: BOUTIQUE STOREFRONT (Home)
            ======================================================== */}
        {activeScreen === 'boutique' && (
          <div>
            {/* Hero Section */}
            <Hero onNavigate={setActiveScreen} />

            {/* Live Hearth Oven Ribbon Trigger */}
            <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 -mt-6 relative z-10">
              <div
                onClick={() => setActiveScreen('oven-schedule')}
                className="bg-white rounded-xl border border-[#EADFD4] p-4 shadow-bakery hover:shadow-bakery-raised transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#FAF6F0] border border-[#EADFD4] flex items-center justify-center text-[#C46D1E] shrink-0">
                    <Flame className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-[#934B00]">
                        Stone Hearth Oven Pull Active
                      </span>
                      <span className="text-[11px] font-mono text-[#807571]">
                        Deck #1 at 242°C
                      </span>
                    </div>
                    <div className="text-xs sm:text-sm text-[#2C221E] font-medium mt-0.5">
                      Signature Country Batards resting on wire racks · Next pull: Ancient Grain Miche (08:45 AM)
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs font-semibold text-[#C46D1E] group-hover:translate-x-1 transition-transform self-end sm:self-auto shrink-0">
                  <span>View Live Oven Schedule</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Featured Morning Collection Section */}
            <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#934B00] uppercase tracking-wider mb-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#C46D1E]" />
                    <span>Pulled Fresh Daily</span>
                  </div>
                  <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#2C221E]">
                    Morning Bake Specials &amp; Classics
                  </h2>
                </div>

                <button
                  onClick={() => setActiveScreen('menu')}
                  className="text-xs font-semibold text-[#C46D1E] hover:text-[#934B00] flex items-center gap-1.5 transition-colors cursor-pointer group"
                >
                  <span>Explore Full 14-Item Bakery Catalog</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* 3-Column Product Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                {BAKERY_PRODUCTS.slice(0, 6).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onQuickAdd={handleQuickAdd}
                    onSelect={setSelectedProduct}
                  />
                ))}
              </div>
            </section>

            {/* Sourdough Craftsmanship Highlight Strip */}
            <section className="bg-white border-y border-[#EADFD4] py-16">
              <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid lg:grid-cols-12 gap-10 items-center">
                  
                  <div className="lg:col-span-5 relative">
                    <img
                      src="https://images.unsplash.com/photo-1549931319-a545dcf3bc73?auto=format&fit=crop&w=800&q=80"
                      alt="Traditional French Baguettes scored diagonally"
                      className="rounded-2xl border border-[#EADFD4] shadow-bakery w-full aspect-[4/3] object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute -bottom-4 -right-4 bg-[#FAF6F0] p-4 rounded-xl border border-[#EADFD4] shadow-bakery hidden sm:block">
                      <div className="font-serif text-2xl font-bold text-[#2C221E]">36h</div>
                      <div className="text-[10px] text-[#807571] uppercase tracking-wide">Cold Fermentation</div>
                    </div>
                  </div>

                  <div className="lg:col-span-7 space-y-5">
                    <div className="text-xs font-semibold uppercase tracking-wider text-[#C46D1E]">
                      The Maison Marcel Difference
                    </div>
                    <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#2C221E] leading-tight">
                      Why Natural Fermentation Matters for Your Body
                    </h2>
                    <p className="text-sm sm:text-base text-[#4E4541] leading-relaxed">
                      Commercial supermarket bread uses synthetic fast-acting yeast and enzymes to force flour into loaves within 90 minutes. At Maison Marcel, our sourdough rests for a full 36 hours. During this unhurried sleep, beneficial lactobacilli break down complex starches and phytic acid, releasing bioavailable minerals and creating bread that is gentle, deeply aromatic, and nourishing.
                    </p>

                    <div className="grid sm:grid-cols-3 gap-4 pt-2">
                      <div className="p-3 bg-[#FAF6F0] rounded-xl border border-[#EADFD4]/60">
                        <span className="font-serif text-lg font-bold text-[#2C221E] block">100% French</span>
                        <span className="text-xs text-[#807571]">Label Rouge &amp; Stoneground grains</span>
                      </div>
                      <div className="p-3 bg-[#FAF6F0] rounded-xl border border-[#EADFD4]/60">
                        <span className="font-serif text-lg font-bold text-[#2C221E] block">Zero Chemicals</span>
                        <span className="text-xs text-[#807571]">Flour, water, wild levain &amp; sea salt</span>
                      </div>
                      <div className="p-3 bg-[#FAF6F0] rounded-xl border border-[#EADFD4]/60">
                        <span className="font-serif text-lg font-bold text-[#2C221E] block">Stone Hearth</span>
                        <span className="text-xs text-[#807571]">Refractory Alsace deck ovens</span>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        onClick={() => setActiveScreen('craft')}
                        className="inline-flex items-center gap-2 text-xs font-bold text-[#2C221E] hover:text-[#C46D1E] transition-colors cursor-pointer group"
                      >
                        <span>Read Chapter I: The Story of Émile Levain Starter</span>
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>

                  </div>

                </div>
              </div>
            </section>

            {/* Café Ambience & Morning Table Banner */}
            <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
              <div className="bg-[#2C221E] rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="max-w-xl space-y-3 z-10">
                  <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#C46D1E] font-semibold">
                    <Coffee className="w-4 h-4" />
                    <span>Café Marcel Service</span>
                  </div>
                  <h3 className="font-serif text-2xl sm:text-4xl font-bold leading-tight">
                    Start Your Morning in the Sunlit Solarium
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                    Sip double-shot Ethiopian flat whites alongside warm twice-baked almond croissants and heirloom tomato tartines overlooking the cobblestones.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 z-10 w-full md:w-auto shrink-0">
                  <button
                    onClick={() => setActiveScreen('reserve')}
                    className="px-6 py-3.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white rounded-xl text-xs font-semibold shadow-bakery transition-all cursor-pointer whitespace-nowrap text-center"
                  >
                    Reserve a Café Table
                  </button>
                  <button
                    onClick={() => setActiveScreen('menu')}
                    className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap text-center"
                  >
                    Pre-Order for Counter Pickup
                  </button>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* ========================================================
            SCREEN 2: BAKERY MENU & ORDER AHEAD
            ======================================================== */}
        {activeScreen === 'menu' && (
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
            
            {/* Header & Search */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-[#934B00] uppercase tracking-wider mb-2">
                  <Wheat className="w-4 h-4 text-[#C46D1E]" />
                  <span>Daily Hearth &amp; Pastry Selection</span>
                </div>
                <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C221E]">
                  Bakery Catalog &amp; Order Ahead
                </h1>
                <p className="text-xs sm:text-sm text-[#807571] mt-2">
                  Choose your artisan loaves, pastries, and pantry accompaniments. Packaged fresh for counter pickup.
                </p>
              </div>

              {/* Instant Search Bar */}
              <div className="relative w-full md:w-72">
                <Search className="w-4 h-4 text-[#807571] absolute left-3 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search baguette, einkorn, tartine..."
                  className="w-full pl-9 pr-4 py-2.5 bg-white border border-[#EADFD4] rounded-xl text-xs text-[#2C221E] focus:outline-none focus:border-[#C46D1E] focus:ring-2 focus:ring-[#C46D1E]/15 shadow-sm"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-2.5 text-xs text-[#807571] hover:text-[#2C221E]"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {/* Category Filter Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-4 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    selectedCategory === cat.id
                      ? 'bg-[#2C221E] text-white shadow-bakery-sm'
                      : 'bg-white text-[#4E4541] border border-[#EADFD4] hover:bg-[#FAF6F0]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Dietary Sub-Filters */}
            <div className="flex items-center gap-2 overflow-x-auto pb-6 mb-8 text-xs text-[#807571]">
              <span className="font-semibold text-[#2C221E] flex items-center gap-1 shrink-0">
                <Filter className="w-3.5 h-3.5" />
                Dietary:
              </span>
              {[
                { id: 'all', label: 'All Ingredients' },
                { id: 'naturally leavened', label: 'Naturally Leavened' },
                { id: 'vegan', label: 'Vegan Friendly' },
                { id: 'heritage', label: 'Heritage Grains' },
                { id: 'aop', label: 'AOP French Butter' },
              ].map((diet) => (
                <button
                  key={diet.id}
                  onClick={() => setSelectedDietary(diet.id)}
                  className={`px-3 py-1 rounded-full text-[11px] cursor-pointer transition-colors whitespace-nowrap ${
                    selectedDietary === diet.id
                      ? 'bg-[#C46D1E] text-white font-semibold'
                      : 'bg-white border border-[#EADFD4] text-[#807571] hover:text-[#2C221E]'
                  }`}
                >
                  {diet.label}
                </button>
              ))}
            </div>

            {/* Products Grid */}
            {filteredProducts.length === 0 ? (
              <div className="py-16 text-center bg-white rounded-2xl border border-[#EADFD4] p-8 max-w-md mx-auto">
                <Wheat className="w-10 h-10 text-[#807571] mx-auto mb-3" />
                <h3 className="font-serif text-lg font-bold text-[#2C221E]">
                  No bakery creations match your filter
                </h3>
                <p className="text-xs text-[#807571] mt-1 mb-4">
                  Try adjusting your search terms or resetting the category filter.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('all');
                    setSelectedDietary('all');
                    setSearchQuery('');
                  }}
                  className="px-4 py-2 bg-[#C46D1E] text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onQuickAdd={handleQuickAdd}
                    onSelect={setSelectedProduct}
                  />
                ))}
              </div>
            )}

          </div>
        )}

        {/* ========================================================
            SCREEN 3: LIVE OVEN SCHEDULE
            ======================================================== */}
        {activeScreen === 'oven-schedule' && (
          <OvenScheduleScreen
            onNotify={handleOvenBatchNotify}
            onOrderProduct={(productName) => {
              setActiveScreen('menu');
              setSearchQuery(productName.split(' ')[0]);
            }}
          />
        )}

        {/* ========================================================
            SCREEN 4: RESERVE CAFÉ TABLE
            ======================================================== */}
        {activeScreen === 'reserve' && (
          <ReservationScreen
            onReservationConfirmed={handleReservationConfirmed}
            onExploreMenu={() => setActiveScreen('menu')}
          />
        )}

        {/* ========================================================
            SCREEN 5: OUR CRAFT & FERMENTATION NARRATIVE
            ======================================================== */}
        {activeScreen === 'craft' && (
          <CraftStoryScreen onExploreMenu={() => setActiveScreen('menu')} />
        )}

        {/* ========================================================
            SCREEN 6: MY ORDERS & LIVE BAKE TRACKING
            ======================================================== */}
        {activeScreen === 'orders' && (
          <OrdersTrackerScreen
            orders={orders}
            onExploreMenu={() => setActiveScreen('menu')}
          />
        )}

      </main>

      {/* Footer */}
      <Footer onNavigate={setActiveScreen} onToast={addToast} />

      {/* Product Detail Modal (PDP) */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleModalAddToCart}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={handleProceedToCheckout}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        subtotal={cartSubtotal}
        discount={checkoutDiscount}
        pickupSlot={checkoutPickupSlot}
        onOrderCompleted={handleOrderCompleted}
      />

    </div>
  );
}
