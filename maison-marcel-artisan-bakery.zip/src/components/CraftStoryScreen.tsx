import React from 'react';
import { BAKERY_STORY, BAKERY_REVIEWS } from '../data/bakeryData';
import { Wheat, Flame, Clock, Award, Sparkles, Star, ArrowRight } from 'lucide-react';

interface CraftStoryScreenProps {
  onExploreMenu: () => void;
}

export const CraftStoryScreen: React.FC<CraftStoryScreenProps> = ({ onExploreMenu }) => {
  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-16">
      
      {/* Editorial Hero Header */}
      <div className="max-w-3xl">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#934B00] uppercase tracking-wider mb-2">
          <Wheat className="w-4 h-4 text-[#C46D1E]" />
          <span>Artisanal Heritage Since 1928</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C221E] leading-tight">
          The Craft of Slow Fermentation &amp; Living Bread
        </h1>
        <p className="text-sm sm:text-base text-[#4E4541] mt-3 leading-relaxed">
          At Maison Marcel, bread is not treated as a rushed commodity. It is an unhurried, living collaboration between heritage stone-milled grain, pure water, sea salt, and a levain culture tended with reverence for nearly a century.
        </p>
      </div>

      {/* 2-Column Split: The Levain Émile & Heritage Sourcing */}
      <div className="grid lg:grid-cols-2 gap-10 items-center">
        <div className="space-y-5">
          <div className="text-xs font-semibold uppercase tracking-wider text-[#C46D1E]">
            Chapter I
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#2C221E]">
            Meet Émile: Our 98-Year-Old Levain Starter
          </h2>
          <p className="text-sm text-[#4E4541] leading-relaxed">
            In the autumn of 1928, our founder Marcel captured wild airborne yeasts from an organic cider apple orchard in Normandy’s Pays d’Auge. That sourdough mother culture—affectionately christened <em>Émile</em>—has been refreshed twice daily without interruption for four generations.
          </p>
          <p className="text-sm text-[#4E4541] leading-relaxed">
            Unlike commercial baker's yeast that forces dough to inflate in two hours, Émile digests complex gluten proteins slowly over 36 hours. The result: unmatched lactic complexity, an amber blistered ear, and bread that is gentle on modern digestion.
          </p>

          <div className="p-4 bg-white rounded-xl border border-[#EADFD4] shadow-bakery-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#FAF6F0] border border-[#EADFD4] flex items-center justify-center text-[#C46D1E] shrink-0 font-serif font-bold text-lg">
              98
            </div>
            <div className="text-xs">
              <span className="font-bold text-[#2C221E] block">Consecutive Years Active</span>
              <span className="text-[#807571]">Fed with stoneground T80 flour and filtered spring water every 12 hours.</span>
            </div>
          </div>
        </div>

        <div className="relative rounded-2xl overflow-hidden border border-[#EADFD4] shadow-bakery-raised">
          <img
            src="https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=900&q=80"
            alt="Hand shaping naturally fermented sourdough in bannetons"
            className="w-full aspect-[4/3] object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="p-4 bg-white border-t border-[#EADFD4] flex items-center justify-between text-xs text-[#807571]">
            <span>Hand-shaped in willow bannetons dusted with rice flour</span>
            <span className="font-mono text-[#2C221E]">Temp: 4°C Retardation</span>
          </div>
        </div>
      </div>

      {/* The 36-Hour Fermentation Timeline */}
      <div className="p-8 sm:p-10 bg-white rounded-2xl border border-[#EADFD4] shadow-bakery space-y-8">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#C46D1E]">
            Chapter II
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#2C221E] mt-1">
            The 36-Hour Natural Fermentation Ritual
          </h2>
          <p className="text-xs sm:text-sm text-[#807571] mt-1">
            How every single loaf of our Signature Country Batard is crafted.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              step: '01',
              title: 'Autolyse & Stone Mill',
              time: 'Hour 0 – 2',
              desc: 'Heritage T80 stoneground flour rests with mineral water, allowing enzymes to unlock natural sugars before kneading.',
            },
            {
              step: '02',
              title: 'Stretch & Aeration',
              time: 'Hour 2 – 6',
              desc: 'No aggressive mechanical mixer. Dough is gently coiled and stretched by hand every 45 minutes to build silky gluten webs.',
            },
            {
              step: '03',
              title: 'Cold Retardation',
              time: 'Hour 6 – 34',
              desc: 'Shaped loaves rest in linen-lined bannetons at 4°C. Yeasts sleep while beneficial lactic acids deepen flavor and digestibility.',
            },
            {
              step: '04',
              title: 'Refractory Hearth Bake',
              time: 'Hour 34 – 36',
              desc: 'Turned onto 240°C stone decks with dense steam burst, creating the blistered mahogany crust that sings as it cools.',
            },
          ].map((item) => (
            <div key={item.step} className="p-5 bg-[#FAF6F0] rounded-xl border border-[#EADFD4] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-serif text-2xl font-bold text-[#C46D1E]">{item.step}</span>
                  <span className="text-[11px] font-mono text-[#807571] bg-white px-2 py-0.5 rounded border border-[#EADFD4]">
                    {item.time}
                  </span>
                </div>
                <h3 className="font-serif text-base font-bold text-[#2C221E] mb-2">{item.title}</h3>
                <p className="text-xs text-[#4E4541] leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Culinary Credentials & Testimonials */}
      <div className="space-y-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#C46D1E]">
            Critical Praise
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#2C221E] mt-1">
            Endorsed by Chefs, Loved by Locals
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {BAKERY_REVIEWS.map((rev) => (
            <div
              key={rev.id}
              className="p-6 bg-white rounded-2xl border border-[#EADFD4] shadow-bakery flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-1 text-[#C46D1E] mb-3">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#C46D1E]" />
                  ))}
                </div>
                <blockquote className="text-xs sm:text-sm text-[#4E4541] leading-relaxed italic font-serif">
                  "{rev.text}"
                </blockquote>
              </div>

              <div className="pt-4 border-t border-[#EADFD4] mt-4">
                <div className="font-semibold text-xs text-[#2C221E]">{rev.author}</div>
                <div className="text-[11px] text-[#807571]">{rev.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom CTA Banner */}
      <div className="p-8 sm:p-12 bg-[#2C221E] text-white rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="max-w-xl">
          <span className="text-xs uppercase tracking-widest text-[#C46D1E] font-semibold">
            Taste The Difference
          </span>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold mt-1">
            Experience Tomorrow Morning's Hearth Bake
          </h3>
          <p className="text-xs sm:text-sm text-stone-300 mt-2">
            Loaves are limited each day to ensure uncompromising quality. Reserve your morning batch now.
          </p>
        </div>

        <button
          onClick={onExploreMenu}
          className="flex items-center gap-2 px-6 py-3.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white rounded-xl text-xs font-semibold shadow-bakery transition-all cursor-pointer whitespace-nowrap shrink-0 group"
        >
          <span>Explore Boutique Menu</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

    </div>
  );
};
