import React, { useState } from 'react';
import { OVEN_BATCHES } from '../data/bakeryData';
import { OvenBatch } from '../types/bakery';
import { Flame, Clock, Bell, Check, Thermometer, Sparkles, AlertCircle } from 'lucide-react';

interface OvenScheduleScreenProps {
  onNotify: (batchName: string, time: string) => void;
  onOrderProduct: (productName: string) => void;
}

export const OvenScheduleScreen: React.FC<OvenScheduleScreenProps> = ({
  onNotify,
  onOrderProduct,
}) => {
  const [filter, setFilter] = useState<'all' | 'ready' | 'baking' | 'cooling' | 'upcoming'>('all');
  const [notifiedBatches, setNotifiedBatches] = useState<string[]>([]);

  const filteredBatches = OVEN_BATCHES.filter((b) => {
    if (filter === 'all') return true;
    if (filter === 'ready') return b.status === 'ready';
    if (filter === 'baking') return b.status === 'baking';
    if (filter === 'cooling') return b.status === 'cooling';
    if (filter === 'upcoming') return b.status === 'proofing' || b.status === 'upcoming';
    return true;
  });

  const handleNotifyToggle = (batch: OvenBatch) => {
    if (notifiedBatches.includes(batch.id)) {
      setNotifiedBatches(notifiedBatches.filter((id) => id !== batch.id));
    } else {
      setNotifiedBatches([...notifiedBatches, batch.id]);
      onNotify(batch.productName, batch.timeSlot);
    }
  };

  const getStatusBadge = (status: OvenBatch['status']) => {
    switch (status) {
      case 'ready':
        return (
          <span className="text-xs font-semibold text-[#3B5241] bg-[#6D8B74]/15 px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#6D8B74]" />
            Fresh on Marble Counter
          </span>
        );
      case 'cooling':
        return (
          <span className="text-xs font-semibold text-[#8A4A0F] bg-[#C46D1E]/15 px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C46D1E]" />
            Cooling on Wire Racks (Singing Crust)
          </span>
        );
      case 'baking':
        return (
          <span className="text-xs font-semibold text-rose-800 bg-rose-100 px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-rose-600" />
            In Stone Hearth (235°C)
          </span>
        );
      case 'proofing':
        return (
          <span className="text-xs font-semibold text-amber-800 bg-amber-100 px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-700" />
            Final Cold Proof in Bannetons
          </span>
        );
      case 'upcoming':
        return (
          <span className="text-xs font-semibold text-[#807571] bg-[#FAF6F0] border border-[#EADFD4] px-2.5 py-1 rounded-full">
            Scheduled Afternoon Hearth Pull
          </span>
        );
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
      
      {/* Editorial Header */}
      <div className="max-w-3xl mb-10">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#934B00] uppercase tracking-wider mb-2">
          <Flame className="w-4 h-4 text-[#C46D1E]" />
          <span>Fringand Refractory Stone Decks</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C221E] leading-tight">
          Today's Daily Oven Schedule &amp; Hearth Pulls
        </h1>
        <p className="text-sm sm:text-base text-[#4E4541] mt-3 leading-relaxed">
          Bread has a life of its own. We bake in small batches from 06:00 to 14:00 so your baguette is always warm and crackling. Set an SMS alert to reserve a loaf the instant it leaves the stone deck.
        </p>
      </div>

      {/* Live Hearth Monitoring Banner */}
      <div className="mb-8 p-5 bg-white rounded-2xl border border-[#EADFD4] shadow-bakery flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#FAF6F0] border border-[#EADFD4] flex items-center justify-center text-[#C46D1E]">
            <Thermometer className="w-6 h-6 stroke-1.5" />
          </div>
          <div>
            <div className="text-xs font-bold text-[#2C221E] uppercase tracking-wider">
              Stone Deck Oven #1 (Charentes)
            </div>
            <div className="text-sm text-[#4E4541] mt-0.5">
              Current Hearth Temperature: <strong className="font-mono text-[#2C221E]">242°C</strong> · Steam Injection Active
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs text-[#807571]">
          <div>
            <span className="block font-medium text-[#2C221E]">Next Pull</span>
            <span className="font-mono text-[#C46D1E] font-bold">08:45 AM (Ancient Grain Miche)</span>
          </div>
          <div className="border-l border-[#EADFD4] pl-6 hidden sm:block">
            <span className="block font-medium text-[#2C221E]">Head Baker</span>
            <span>Pierre Marcel</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs (Functional segmented controls) */}
      <div className="flex items-center gap-1.5 p-1 bg-[#FAF6F0] border border-[#EADFD4] rounded-xl w-fit mb-8 overflow-x-auto max-w-full">
        {[
          { id: 'all', label: 'All Batches' },
          { id: 'ready', label: 'Ready on Counter' },
          { id: 'cooling', label: 'Cooling Racks' },
          { id: 'baking', label: 'In Hearth Oven' },
          { id: 'upcoming', label: 'Upcoming' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id as any)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              filter === tab.id
                ? 'bg-white text-[#2C221E] shadow-bakery-sm border border-[#EADFD4]'
                : 'text-[#807571] hover:text-[#2C221E]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Batch Schedule Timeline Cards */}
      <div className="space-y-4">
        {filteredBatches.map((batch) => {
          const isNotified = notifiedBatches.includes(batch.id);

          return (
            <div
              key={batch.id}
              className="p-5 sm:p-6 bg-white rounded-2xl border border-[#EADFD4] shadow-bakery hover:shadow-bakery-raised transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
            >
              {/* Left Column: Time & Batch Info */}
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-xl bg-[#FAF6F0] border border-[#EADFD4] flex flex-col items-center justify-center shrink-0">
                  <span className="font-serif text-sm font-bold text-[#2C221E]">
                    {batch.timeSlot.split(' ')[0]}
                  </span>
                  <span className="text-[10px] text-[#807571] uppercase font-mono">
                    {batch.timeSlot.split(' ')[1]}
                  </span>
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    {getStatusBadge(batch.status)}
                    <span className="text-xs text-[#807571]">
                      Batch Size: <strong className="font-mono text-[#2C221E]">{batch.unitsBatch} units</strong>
                    </span>
                  </div>

                  <h3 className="font-serif text-xl font-bold text-[#2C221E]">
                    {batch.productName}
                  </h3>
                  <p className="text-xs italic text-[#807571] font-serif">
                    {batch.frenchName}
                  </p>
                  <p className="text-xs text-[#4E4541] mt-1">
                    Grain Source: <span className="font-medium text-[#2C221E]">{batch.flourOrigin}</span>
                  </p>
                </div>
              </div>

              {/* Center / Progress Gauge */}
              <div className="w-full md:w-56 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-[#807571] font-medium">Bake Progress</span>
                  <span className="font-mono font-bold text-[#2C221E] tabular-nums">
                    {batch.progressPercent}%
                  </span>
                </div>
                <div className="w-full h-2 bg-[#FAF6F0] border border-[#EADFD4] rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-1000 rounded-full ${
                      batch.status === 'ready'
                        ? 'bg-[#6D8B74]'
                        : batch.status === 'cooling'
                        ? 'bg-[#C46D1E]'
                        : batch.status === 'baking'
                        ? 'bg-rose-500'
                        : 'bg-[#D2C4BF]'
                    }`}
                    style={{ width: `${batch.progressPercent}%` }}
                  />
                </div>
                <div className="text-[11px] text-[#807571] text-right">
                  Oven Deck: <strong className="font-mono text-[#2C221E]">{batch.tempCelsius}°C</strong>
                </div>
              </div>

              {/* Right Column: Interactive Buttons */}
              <div className="flex items-center gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-[#EADFD4]">
                {batch.status === 'ready' ? (
                  <button
                    onClick={() => onOrderProduct(batch.productName)}
                    className="w-full md:w-auto px-4 py-2.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white rounded-lg text-xs font-semibold shadow-bakery-sm transition-colors cursor-pointer"
                  >
                    Order from this Batch
                  </button>
                ) : (
                  <button
                    onClick={() => handleNotifyToggle(batch)}
                    className={`w-full md:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isNotified
                        ? 'bg-[#6D8B74] text-white shadow-bakery-sm'
                        : 'bg-[#FAF6F0] hover:bg-white border border-[#EADFD4] text-[#2C221E]'
                    }`}
                  >
                    {isNotified ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>SMS Alert Set</span>
                      </>
                    ) : (
                      <>
                        <Bell className="w-3.5 h-3.5 text-[#C46D1E]" />
                        <span>Notify When Pulled</span>
                      </>
                    )}
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Baker's Advisory Note */}
      <div className="mt-12 p-6 bg-[#FAF6F0] rounded-2xl border border-[#EADFD4] flex items-start gap-4">
        <Sparkles className="w-5 h-5 text-[#C46D1E] shrink-0 mt-0.5" />
        <div className="text-xs sm:text-sm text-[#4E4541] leading-relaxed">
          <strong className="text-[#2C221E] font-serif block text-sm mb-1">
            Boulanger's Temperature &amp; Humidity Note:
          </strong>
          Because we ferment exclusively with our wild levain starter <em className="italic font-serif">Émile</em> and zero commercial baker's yeast, baking pull times may flex by 5-10 minutes depending on ambient morning humidity and barometric pressure.
        </div>
      </div>

    </div>
  );
};
