import React, { useState } from 'react';
import { CartItem } from '../types/bakery';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, Clock, CheckCircle } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, quantity: number) => void;
  onRemoveItem: (index: number) => void;
  onProceedToCheckout: (appliedPromo?: { code: string; discountAmount: number }, pickupSlot?: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}) => {
  if (!isOpen) return null;

  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discountAmount: number } | null>(null);
  const [promoError, setPromoError] = useState('');
  const [selectedPickupSlot, setSelectedPickupSlot] = useState('08:30 AM - 09:00 AM (Fresh Hearth Pull)');

  const pickupSlots = [
    '08:30 AM - 09:00 AM (Fresh Hearth Pull)',
    '09:30 AM - 10:00 AM',
    '10:30 AM - 11:00 AM',
    '11:45 AM - 12:15 PM (Afternoon Batch)',
    '02:00 PM - 02:30 PM',
  ];

  // Calculate items subtotal
  const rawSubtotal = items.reduce((sum, item) => {
    const addonsTotal = (item.selectedAddons || []).reduce((aSum, a) => aSum + a.price, 0);
    return sum + (item.product.price + addonsTotal) * item.quantity;
  }, 0);

  // Apply promo calculation
  let discountAmount = 0;
  if (appliedPromo) {
    discountAmount = appliedPromo.discountAmount;
  }

  const subtotalAfterDiscount = Math.max(0, rawSubtotal - discountAmount);
  const tax = subtotalAfterDiscount * 0.0825;
  const grandTotal = subtotalAfterDiscount + tax;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    const code = promoCode.trim().toUpperCase();

    if (!code) return;

    if (code === 'BONJOUR10') {
      const discount = rawSubtotal * 0.10;
      setAppliedPromo({ code: 'BONJOUR10', discountAmount: discount });
      setPromoCode('');
    } else if (code === 'ARTISAN') {
      const discount = Math.min(5.00, rawSubtotal);
      setAppliedPromo({ code: 'ARTISAN', discountAmount: discount });
      setPromoCode('');
    } else {
      setPromoError('Invalid code. Try "BONJOUR10" or "ARTISAN"');
    }
  };

  const handleRemovePromo = () => {
    setAppliedPromo(null);
    setPromoError('');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#2C221E]/50 backdrop-blur-sm animate-in fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF6F0] border-l border-[#EADFD4] shadow-bakery-modal flex flex-col">
          
          {/* Drawer Header */}
          <div className="px-6 py-5 bg-white border-b border-[#EADFD4] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-[#C46D1E]" />
              <h2 className="font-serif text-xl font-bold text-[#2C221E]">
                Your Order Bag
              </h2>
              <span className="text-xs bg-[#FAF6F0] border border-[#EADFD4] text-[#2C221E] px-2 py-0.5 rounded-full font-mono tabular-nums font-semibold">
                {items.reduce((acc, i) => acc + i.quantity, 0)}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-[#807571] hover:text-[#2C221E] rounded-lg hover:bg-[#FAF6F0] transition-colors cursor-pointer"
              aria-label="Close order bag"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 rounded-full bg-white border border-[#EADFD4] flex items-center justify-center mb-4 text-[#807571]">
                  <ShoppingBag className="w-8 h-8 text-[#C46D1E]/60 stroke-1" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-[#2C221E]">
                  Your bag is currently empty
                </h3>
                <p className="text-xs text-[#807571] max-w-xs mt-1 mb-6 leading-relaxed">
                  Our morning batches of naturally leavened sourdough and warm laminated viennoiserie await you.
                </p>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white text-xs font-semibold rounded-lg shadow-bakery-sm transition-all cursor-pointer"
                >
                  Explore Today's Bake
                </button>
              </div>
            ) : (
              <>
                {/* Itemized Line Items */}
                <div className="space-y-3">
                  {items.map((item, index) => {
                    const addonsCost = (item.selectedAddons || []).reduce((a, b) => a + b.price, 0);
                    const lineTotal = (item.product.price + addonsCost) * item.quantity;

                    return (
                      <div
                        key={`${item.product.id}-${index}`}
                        className="p-3.5 bg-white rounded-xl border border-[#EADFD4] shadow-bakery-sm flex gap-3.5"
                      >
                        {/* Thumbnail */}
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-16 h-16 rounded-lg object-cover border border-[#EADFD4] shrink-0"
                          referrerPolicy="no-referrer"
                        />

                        {/* Details */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="font-serif text-sm font-semibold text-[#2C221E] truncate">
                              {item.product.name}
                            </h4>
                            <button
                              onClick={() => onRemoveItem(index)}
                              className="text-[#807571] hover:text-[#BA1A1A] transition-colors p-1 -mr-1 -mt-1 cursor-pointer"
                              aria-label="Remove item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Slicing & Addons */}
                          {item.selectedSlicing && (
                            <div className="text-[11px] text-[#807571] mt-0.5">
                              Slicing: <span className="capitalize font-medium text-[#2C221E]">{item.selectedSlicing}</span>
                            </div>
                          )}

                          {item.selectedAddons && item.selectedAddons.length > 0 && (
                            <div className="text-[10px] text-[#807571] truncate mt-0.5">
                              + {item.selectedAddons.map((a) => a.name).join(', ')}
                            </div>
                          )}

                          {/* Quantity & Price */}
                          <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#EADFD4]/60">
                            <div className="flex items-center border border-[#EADFD4] rounded bg-[#FAF6F0]">
                              <button
                                onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                                className="px-2 py-0.5 hover:bg-white text-[#2C221E] text-xs transition-colors cursor-pointer"
                                aria-label="Decrease quantity"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="w-6 text-center text-xs font-mono font-bold text-[#2C221E] tabular-nums">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                                className="px-2 py-0.5 hover:bg-white text-[#2C221E] text-xs transition-colors cursor-pointer"
                                aria-label="Increase quantity"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            <span className="font-mono text-xs font-bold text-[#2C221E] tabular-nums">
                              ${lineTotal.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Pickup Window Selection */}
                <div className="p-4 bg-white rounded-xl border border-[#EADFD4] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#2C221E]">
                    <Clock className="w-4 h-4 text-[#C46D1E]" />
                    <span>Select Bakery Pickup Window</span>
                  </div>
                  <select
                    value={selectedPickupSlot}
                    onChange={(e) => setSelectedPickupSlot(e.target.value)}
                    className="w-full text-xs bg-[#FAF6F0] border border-[#EADFD4] rounded-lg px-3 py-2 text-[#2C221E] focus:outline-none focus:border-[#C46D1E] cursor-pointer"
                  >
                    {pickupSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-[#807571] leading-relaxed">
                    Breads are boxed warm directly from the hearth cooling racks 10 minutes prior to arrival.
                  </p>
                </div>

                {/* Promo Code Module */}
                <div className="p-4 bg-white rounded-xl border border-[#EADFD4] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#2C221E] flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-[#C46D1E]" />
                      Baker's Privilege Code
                    </span>
                    <span className="text-[10px] text-[#807571]">Try "BONJOUR10" or "ARTISAN"</span>
                  </div>

                  {appliedPromo ? (
                    <div className="flex items-center justify-between p-2.5 bg-[#6D8B74]/10 border border-[#6D8B74]/30 rounded-lg text-xs">
                      <div className="flex items-center gap-2 text-[#3B5241] font-medium">
                        <CheckCircle className="w-4 h-4" />
                        <span>Code <strong>{appliedPromo.code}</strong> applied (-${appliedPromo.discountAmount.toFixed(2)})</span>
                      </div>
                      <button
                        onClick={handleRemovePromo}
                        className="text-xs text-[#BA1A1A] hover:underline cursor-pointer"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleApplyPromo} className="flex gap-2">
                      <input
                        type="text"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        placeholder="e.g. BONJOUR10"
                        className="flex-1 text-xs px-3 py-2 bg-[#FAF6F0] border border-[#EADFD4] rounded-lg uppercase tracking-wider text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                      />
                      <button
                        type="submit"
                        className="px-3.5 py-2 text-xs font-semibold bg-[#2C221E] hover:bg-[#150D0A] text-white rounded-lg transition-colors cursor-pointer"
                      >
                        Apply
                      </button>
                    </form>
                  )}

                  {promoError && (
                    <div className="text-[11px] text-[#BA1A1A]">{promoError}</div>
                  )}
                </div>

                {/* Pricing Summary Breakdown */}
                <div className="p-4 bg-white rounded-xl border border-[#EADFD4] space-y-2 text-xs">
                  <div className="flex justify-between text-[#807571]">
                    <span>Items Subtotal</span>
                    <span className="font-mono tabular-nums">${rawSubtotal.toFixed(2)}</span>
                  </div>

                  {appliedPromo && (
                    <div className="flex justify-between text-[#6D8B74] font-medium">
                      <span>Artisan Privilege ({appliedPromo.code})</span>
                      <span className="font-mono tabular-nums">-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-[#807571]">
                    <span>Estimated Local Tax (8.25%)</span>
                    <span className="font-mono tabular-nums">${tax.toFixed(2)}</span>
                  </div>

                  <div className="pt-2 border-t border-[#EADFD4] flex justify-between items-baseline text-sm font-bold text-[#2C221E]">
                    <span>Total Due</span>
                    <span className="font-mono text-base text-[#C46D1E] tabular-nums">
                      ${grandTotal.toFixed(2)}
                    </span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Drawer Sticky Footer with CTA */}
          {items.length > 0 && (
            <div className="p-6 bg-white border-t border-[#EADFD4] shadow-lg">
              <button
                onClick={() => onProceedToCheckout(appliedPromo || undefined, selectedPickupSlot)}
                className="w-full flex items-center justify-between px-6 py-3.5 bg-[#2C221E] hover:bg-[#150D0A] active:bg-[#000000] text-[#FAF6F0] rounded-xl font-semibold text-sm transition-all duration-200 shadow-bakery cursor-pointer group"
              >
                <span>Proceed to Pickup &amp; Pay</span>
                <div className="flex items-center gap-2 font-mono tabular-nums">
                  <span>${grandTotal.toFixed(2)}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
              <p className="text-[11px] text-center text-[#807571] mt-2.5">
                Baked fresh daily · Free cancellation up to 1h before pickup window
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
