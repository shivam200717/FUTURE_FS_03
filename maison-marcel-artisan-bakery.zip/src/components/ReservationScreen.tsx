import React, { useState } from 'react';
import { ReservationRequest } from '../types/bakery';
import { CalendarDays, Clock, Users, Coffee, Check, Sparkles, MapPin, Download } from 'lucide-react';

interface ReservationScreenProps {
  onReservationConfirmed: (res: ReservationRequest) => void;
  onExploreMenu: () => void;
}

export const ReservationScreen: React.FC<ReservationScreenProps> = ({
  onReservationConfirmed,
  onExploreMenu,
}) => {
  const [name, setName] = useState('Julien Moreau');
  const [email, setEmail] = useState('julien.moreau@example.com');
  const [phone, setPhone] = useState('+33 6 88 12 43 90');
  const [date, setDate] = useState('Today, October 26');
  const [time, setTime] = useState('09:30 AM');
  const [guests, setGuests] = useState(2);
  const [seatingArea, setSeatingArea] = useState<'solarium' | 'main-hall' | 'garden-terrace'>('solarium');
  const [specialNotes, setSpecialNotes] = useState('Table near natural light for morning reading.');

  const [confirmedReservation, setConfirmedReservation] = useState<ReservationRequest | null>(null);

  const seatingOptions = [
    {
      id: 'solarium' as const,
      title: 'Sunlit Window Solarium',
      desc: 'Arched glass windows overlooking cobblestone rue, flooded with gentle morning sun.',
      badge: 'Most Popular for Breakfast',
      image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=600&q=80',
    },
    {
      id: 'main-hall' as const,
      title: 'Main Boulangerie Hall',
      desc: 'Beside the Carrara marble pastry vitrine and the intoxicating aroma of hearth baking.',
      badge: 'Bakery Energy',
      image: 'https://images.unsplash.com/photo-1559925393-8be0ec4767c8?auto=format&fit=crop&w=600&q=80',
    },
    {
      id: 'garden-terrace' as const,
      title: 'Courtyard Garden Terrace',
      desc: 'Private quiet stone courtyard shaded by heirloom fig trees, rosemary planters, and heated bistro seating.',
      badge: 'Quiet & Open-Air',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=600&q=80',
    },
  ];

  const timeSlots = ['08:00 AM', '09:00 AM', '09:30 AM', '11:00 AM', '12:30 PM', '02:00 PM', '03:30 PM'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newRes: ReservationRequest = {
      id: `RES-${Math.floor(1000 + Math.random() * 9000)}`,
      name,
      email,
      phone,
      date,
      time,
      guests,
      seatingArea,
      specialNotes,
    };
    setConfirmedReservation(newRes);
    onReservationConfirmed(newRes);
  };

  const handleDownloadCalendarPass = () => {
    if (!confirmedReservation) return;
    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Maison Marcel//Artisan Bakery Reservation//EN
BEGIN:VEVENT
UID:${confirmedReservation.id}@maisonmarcel.fr
DTSTAMP:20261026T080000Z
SUMMARY:Table at Maison Marcel Artisan Café (${confirmedReservation.guests} Guests)
DESCRIPTION:Table reservation in the ${confirmedReservation.seatingArea} area. Maison Marcel Boulangerie, 42 Rue des Artisans.
LOCATION:42 Rue des Artisans, Paris 3e
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;
    const blob = new Blob([icsContent], { type: 'text/calendar' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MaisonMarcel_${confirmedReservation.id}.ics`;
    link.click();
  };

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
      
      {/* Header */}
      <div className="max-w-2xl mb-10">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#934B00] uppercase tracking-wider mb-2">
          <Coffee className="w-4 h-4 text-[#C46D1E]" />
          <span>Café Marcel Hospitality</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C221E] leading-tight">
          Reserve a Café Table
        </h1>
        <p className="text-sm sm:text-base text-[#4E4541] mt-3 leading-relaxed">
          Join us for slow morning coffee, warm viennoiserie pulled fresh from the hearth, and savory sourdough tartines. Tables are reserved for 75 minutes.
        </p>
      </div>

      {confirmedReservation ? (
        /* Reservation Confirmed View */
        <div className="max-w-xl mx-auto p-8 bg-white rounded-2xl border border-[#EADFD4] shadow-bakery-raised text-center space-y-6 animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-full bg-[#6D8B74]/15 border border-[#6D8B74]/30 flex items-center justify-center mx-auto text-[#3B5241]">
            <Check className="w-8 h-8 stroke-3" />
          </div>

          <div>
            <span className="text-xs uppercase tracking-widest text-[#807571] font-semibold">
              Reservation Confirmed
            </span>
            <h2 className="font-serif text-3xl font-bold text-[#2C221E] mt-1">
              {confirmedReservation.id}
            </h2>
            <p className="text-sm text-[#4E4541] mt-2">
              We look forward to welcoming you, {confirmedReservation.name}. Your table is booked!
            </p>
          </div>

          <div className="p-5 bg-[#FAF6F0] rounded-xl border border-[#EADFD4] text-xs space-y-2 text-left">
            <div className="flex justify-between">
              <span className="text-[#807571]">Date &amp; Time</span>
              <strong className="text-[#2C221E] font-serif">{confirmedReservation.date} at {confirmedReservation.time}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-[#807571]">Guests</span>
              <strong className="text-[#2C221E]">{confirmedReservation.guests} {confirmedReservation.guests === 1 ? 'Guest' : 'Guests'}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-[#807571]">Seating Area</span>
              <strong className="text-[#2C221E] capitalize">{confirmedReservation.seatingArea.replace('-', ' ')}</strong>
            </div>
            <div className="flex justify-between pt-2 border-t border-[#EADFD4]">
              <span className="text-[#807571]">Location</span>
              <span className="text-[#2C221E]">42 Rue des Artisans, Paris 3e</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={handleDownloadCalendarPass}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-white border border-[#2C221E] text-[#2C221E] hover:bg-[#FAF6F0] rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Add to Apple / Google Calendar</span>
            </button>

            <button
              onClick={onExploreMenu}
              className="flex-1 py-3 bg-[#C46D1E] hover:bg-[#D9822B] text-white rounded-xl text-xs font-semibold shadow-bakery-sm transition-colors cursor-pointer"
            >
              Pre-Order Breakfast Loaves &rarr;
            </button>
          </div>
        </div>
      ) : (
        /* Reservation Form */
        <form onSubmit={handleSubmit} className="grid lg:grid-cols-12 gap-10">
          
          {/* Left Column: Seating Ambience Selection (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block mb-3">
                1. Select Café Seating Ambience
              </label>

              <div className="space-y-4">
                {seatingOptions.map((opt) => {
                  const isSelected = seatingArea === opt.id;
                  return (
                    <div
                      key={opt.id}
                      onClick={() => setSeatingArea(opt.id)}
                      className={`relative flex flex-col sm:flex-row gap-4 p-4 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'border-[#C46D1E] bg-white shadow-bakery ring-2 ring-[#C46D1E]/15'
                          : 'border-[#EADFD4] bg-white/70 hover:bg-white hover:border-[#807571]'
                      }`}
                    >
                      <img
                        src={opt.image}
                        alt={opt.title}
                        className="w-full sm:w-32 h-28 rounded-xl object-cover shrink-0 border border-[#EADFD4]"
                        referrerPolicy="no-referrer"
                      />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <h3 className="font-serif text-base font-bold text-[#2C221E]">
                            {opt.title}
                          </h3>
                          <span className="text-[10px] font-semibold text-[#8A4A0F] bg-[#C46D1E]/10 px-2 py-0.5 rounded-full">
                            {opt.badge}
                          </span>
                        </div>
                        <p className="text-xs text-[#4E4541] leading-relaxed">
                          {opt.desc}
                        </p>
                      </div>

                      {/* Selection radio visual */}
                      <div className="absolute top-4 right-4 sm:static flex items-center justify-center">
                        <div
                          className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                            isSelected
                              ? 'border-[#C46D1E] bg-[#C46D1E] text-white'
                              : 'border-[#807571] bg-white'
                          }`}
                        >
                          {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Special Requests */}
            <div className="p-4 bg-white rounded-xl border border-[#EADFD4]">
              <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block mb-1.5">
                Special Occasion or Dietary Note
              </label>
              <textarea
                rows={2}
                value={specialNotes}
                onChange={(e) => setSpecialNotes(e.target.value)}
                placeholder="Anniversary, high chair required, gluten sensitivity note, etc."
                className="w-full text-xs px-3 py-2 bg-[#FAF6F0] border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
              />
            </div>
          </div>

          {/* Right Column: Date, Time & Contact Info (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 bg-white rounded-2xl border border-[#EADFD4] shadow-bakery space-y-5">
              
              {/* Guest Count */}
              <div>
                <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block mb-2">
                  2. Number of Guests
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5, 6].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setGuests(num)}
                      className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                        guests === num
                          ? 'bg-[#C46D1E] border-[#C46D1E] text-white shadow-bakery-sm'
                          : 'bg-[#FAF6F0] border-[#EADFD4] text-[#2C221E] hover:bg-white'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              {/* Date Selection */}
              <div>
                <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block mb-2">
                  3. Date
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['Today, October 26', 'Tomorrow, October 27'].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDate(d)}
                      className={`py-2 px-3 text-xs font-semibold rounded-lg border text-left cursor-pointer transition-colors ${
                        date === d
                          ? 'bg-[#2C221E] border-[#2C221E] text-white'
                          : 'bg-[#FAF6F0] border-[#EADFD4] text-[#2C221E] hover:bg-white'
                      }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Slots */}
              <div>
                <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block mb-2">
                  4. Seating Time
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {timeSlots.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setTime(slot)}
                      className={`py-2 px-2 text-xs font-mono font-semibold rounded-lg border text-center cursor-pointer transition-colors ${
                        time === slot
                          ? 'bg-[#C46D1E] border-[#C46D1E] text-white'
                          : 'bg-[#FAF6F0] border-[#EADFD4] text-[#2C221E] hover:bg-white'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Contact Fields */}
              <div className="space-y-3 pt-3 border-t border-[#EADFD4]">
                <div>
                  <span className="text-[11px] font-medium text-[#4E4541] block mb-1">Your Name</span>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-[#FAF6F0] border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[11px] font-medium text-[#4E4541] block mb-1">Phone</span>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-[#FAF6F0] border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] font-medium text-[#4E4541] block mb-1">Email</span>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-[#FAF6F0] border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white rounded-xl text-xs font-semibold shadow-bakery hover:shadow-bakery-raised transition-all cursor-pointer"
              >
                Confirm Table Reservation (Complimentary)
              </button>

              <div className="text-[11px] text-center text-[#807571]">
                No cancellation fees · Walk-ins welcome based on marble counter capacity
              </div>

            </div>
          </div>

        </form>
      )}

    </div>
  );
};
