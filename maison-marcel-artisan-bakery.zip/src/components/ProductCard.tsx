import React, { useState } from 'react';
import { BakeryProduct } from '../types/bakery';
import { Plus, Check, Sparkles, Wheat } from 'lucide-react';

interface ProductCardProps {
  product: BakeryProduct;
  onQuickAdd: (product: BakeryProduct) => void;
  onSelect: (product: BakeryProduct) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onQuickAdd,
  onSelect,
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const handleAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickAdd(product);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1200);
  };

  return (
    <article
      onClick={() => onSelect(product)}
      className="group relative flex flex-col bg-white rounded-xl border border-[#EADFD4] shadow-bakery hover:shadow-bakery-raised transition-all duration-300 hover:-translate-y-1 cursor-pointer overflow-hidden"
    >
      {/* 4:3 Bakery Photography Container */}
      <div className="relative aspect-[4/3] w-full bg-[#F7F3ED] overflow-hidden border-b border-[#EADFD4]/60">
        {!imageError ? (
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            referrerPolicy="no-referrer"
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
            className={`w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-gradient-to-br from-[#FAF6F0] to-[#EADFD4]/40 text-[#807571]">
            <Wheat className="w-10 h-10 text-[#C46D1E]/60 mb-2 stroke-1" />
            <span className="font-serif text-sm font-medium text-[#2C221E] text-center">
              {product.frenchName}
            </span>
            <span className="text-xs text-[#807571] mt-1">Artisan Batch</span>
          </div>
        )}

        {product.isMorningSpecial && (
          <div className="absolute top-3 left-3 bg-[#FAF6F0]/95 backdrop-blur-md border border-[#EADFD4] px-2.5 py-1 rounded text-[11px] font-semibold tracking-wider text-[#934B00] uppercase shadow-sm">
            Morning Special
          </div>
        )}

        {product.isPopular && !product.isMorningSpecial && (
          <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md border border-[#EADFD4] px-2.5 py-1 rounded text-[11px] font-medium tracking-wider text-[#2C221E] uppercase shadow-sm flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#C46D1E]" />
            Boulanger Choice
          </div>
        )}
      </div>

      {/* Card Content Stack */}
      <div className="flex flex-col flex-1 p-5">
        <div className="flex items-center gap-2 text-xs text-[#807571] font-medium mb-1.5 flex-wrap">
          <span>
            {product.fermentationHours > 0
              ? `${product.fermentationHours}h Ferment`
              : 'Daily Fresh Bake'}
          </span>
          <span aria-hidden="true" className="text-[#D2C4BF]">·</span>
          <span className="truncate max-w-[150px]">{product.dietaryTags[0] || 'French Craft'}</span>
        </div>

        <h3 className="font-serif text-lg sm:text-xl font-semibold text-[#2C221E] group-hover:text-[#C46D1E] transition-colors leading-snug">
          {product.name}
        </h3>
        <p className="text-xs italic text-[#807571] mt-0.5 mb-2 font-serif">
          {product.frenchName}
        </p>

        <p className="text-xs text-[#4E4541] line-clamp-2 leading-relaxed mb-4 flex-1">
          {product.description}
        </p>

        <div className="flex items-center justify-between pt-3 border-t border-[#EADFD4]/60 mt-auto">
          <div className="flex flex-col">
            <span className="text-[11px] uppercase tracking-wider text-[#807571] font-medium">
              Price
            </span>
            <span className="text-lg font-bold text-[#2C221E] font-mono tabular-nums">
              ${product.price.toFixed(2)}
            </span>
          </div>

          <button
            onClick={handleAddClick}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer shadow-bakery-sm ${
              justAdded
                ? 'bg-[#6D8B74] text-white scale-95'
                : 'bg-[#C46D1E] hover:bg-[#D9822B] active:bg-[#A35515] text-white hover:shadow-bakery'
            }`}
            aria-label={`Add ${product.name} to order`}
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5 stroke-2" />
                <span>Added</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5 stroke-2" />
                <span>Add</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
};
