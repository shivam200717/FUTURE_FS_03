import React, { useState } from 'react';
import { ActiveScreen } from './Header';
import { Wheat, Mail, Check, ArrowRight } from 'lucide-react';

interface FooterProps {
  onNavigate: (screen: ActiveScreen) => void;
  onToast: (msg: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onToast }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setSubscribed(true);
    onToast('Merci! You have been subscribed to our weekly baker’s dispatch.');
    setTimeout(() => {
      setNewsletterEmail('');
      setSubscribed(false);
    }, 3000);
  };

  return (
    <footer className="bg-white border-t border-[#EADFD4] mt-20 pt-16 pb-12">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#EADFD4]">
          
          {/* Brand & Manifesto Column (5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <span className="font-serif text-2xl font-bold tracking-tight text-[#2C221E] block">
              Maison Marcel
            </span>
            <p className="text-xs sm:text-sm text-[#4E4541] leading-relaxed max-w-sm">
              Artisanal neighborhood boulangerie and specialty café. Naturally leavened sourdough, slow cold fermentation, hand-rolled viennoiserie, and single-origin coffee.
            </p>
            <div className="text-xs text-[#807571] space-y-1">
              <div>Boutique: 42 Rue des Artisans, Paris 3e</div>
              <div>Baking Hours: Monday – Sunday · 06:30 – 17:00</div>
            </div>
          </div>

          {/* Quick Navigation (3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#807571] block">
              Boutique &amp; Café
            </span>
            <ul className="space-y-2 text-xs text-[#4E4541]">
              <li>
                <button
                  onClick={() => onNavigate('boutique')}
                  className="hover:text-[#C46D1E] transition-colors cursor-pointer"
                >
                  Boutique Storefront
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('menu')}
                  className="hover:text-[#C46D1E] transition-colors cursor-pointer"
                >
                  Daily Bakery Menu
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('oven-schedule')}
                  className="hover:text-[#C46D1E] transition-colors cursor-pointer"
                >
                  Live Hearth Oven Schedule
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('reserve')}
                  className="hover:text-[#C46D1E] transition-colors cursor-pointer"
                >
                  Reserve a Café Table
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('craft')}
                  className="hover:text-[#C46D1E] transition-colors cursor-pointer"
                >
                  The Émile Sourdough Starter
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter / Weekly Bake Gazette (4 cols) */}
          <div className="md:col-span-4 space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#807571] block">
              The Baker's Weekly Gazette
            </span>
            <p className="text-xs text-[#4E4541] leading-relaxed">
              Receive notifications when seasonal fruit viennoiserie, panettone batches, and weekend sourdough workshops are announced.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="flex gap-2">
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="flex-1 text-xs px-3.5 py-2.5 bg-[#FAF6F0] border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer shrink-0"
                >
                  {subscribed ? <Check className="w-4 h-4" /> : 'Subscribe'}
                </button>
              </div>
            </form>
          </div>

        </div>

        {/* Quiet Sub-footer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#807571]">
          <div>
            &copy; {new Date().getFullYear()} Maison Marcel Boulangerie Artisanale. All rights reserved.
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <Wheat className="w-4 h-4 text-[#C46D1E]" />
            <span>Fermented with love &amp; living cultures in Paris</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
