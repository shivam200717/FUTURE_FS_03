import React from 'react';
import { OrderRecord } from '../types/bakery';
import { Package, Clock, CheckCircle2, Flame, MapPin, Download, ShoppingBag } from 'lucide-react';

interface OrdersTrackerScreenProps {
  orders: OrderRecord[];
  onExploreMenu: () => void;
}

export const OrdersTrackerScreen: React.FC<OrdersTrackerScreenProps> = ({
  orders,
  onExploreMenu,
}) => {
  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      
      {/* Header */}
      <div className="max-w-2xl">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#934B00] uppercase tracking-wider mb-2">
          <Clock className="w-4 h-4 text-[#C46D1E]" />
          <span>Live Bakery Dispatch</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#2C221E] leading-tight">
          My Bakery Orders &amp; Live Bake Status
        </h1>
        <p className="text-sm text-[#4E4541] mt-2">
          Track your hand-shaped sourdough loaves and morning pastries in real time from banneton proofing to hearth pull.
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="p-12 bg-white rounded-2xl border border-[#EADFD4] shadow-bakery text-center max-w-md mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#FAF6F0] border border-[#EADFD4] flex items-center justify-center mx-auto text-[#C46D1E]">
            <ShoppingBag className="w-8 h-8 stroke-1.5" />
          </div>
          <h3 className="font-serif text-xl font-bold text-[#2C221E]">
            No Active Orders Yet
          </h3>
          <p className="text-xs text-[#807571] leading-relaxed">
            When you pre-order morning loaves or fresh pastries, your order tracking timeline and counter pass will appear here.
          </p>
          <button
            onClick={onExploreMenu}
            className="px-5 py-2.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white text-xs font-semibold rounded-lg shadow-bakery-sm transition-colors cursor-pointer"
          >
            Start Your Morning Order
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          {orders.map((order) => {
            const stages = [
              { label: 'Order Received', desc: 'Entered into morning bake queue', done: true },
              { label: 'Dough Shaped & Proofed', desc: 'Resting in willow bannetons', done: true },
              { label: 'Hearth Stone Baking', desc: 'Stone deck at 240°C with steam', done: order.status !== 'received' },
              { label: 'Paper Wrapping', desc: 'Cooling on wire racks & boxed', done: order.status === 'packaging' || order.status === 'ready_for_pickup' || order.status === 'completed' },
              { label: 'Ready for Pickup', desc: 'Awaiting you on marble counter', done: order.status === 'ready_for_pickup' || order.status === 'completed' },
            ];

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-[#EADFD4] shadow-bakery overflow-hidden"
              >
                {/* Order Top Strip */}
                <div className="p-6 bg-[#FAF6F0] border-b border-[#EADFD4] flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-white border border-[#EADFD4] flex items-center justify-center text-[#C46D1E] font-serif font-bold text-sm">
                      MM
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-serif text-lg font-bold text-[#2C221E]">
                          Order {order.orderNumber}
                        </h3>
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#C46D1E]/15 text-[#8A4A0F]">
                          In Hearth Queue
                        </span>
                      </div>
                      <span className="text-xs text-[#807571]">
                        Placed at {order.createdAt} · Window: <strong>{order.pickupTime}</strong>
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-[#807571] block">Total Amount</span>
                    <span className="font-mono text-base font-bold text-[#2C221E] tabular-nums">
                      ${order.total.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Live Timeline */}
                <div className="p-6 sm:p-8 border-b border-[#EADFD4]">
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-[#807571] mb-6">
                    Baking &amp; Fulfillment Timeline
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 relative">
                    {stages.map((stage, idx) => (
                      <div key={idx} className="flex sm:flex-col items-start gap-3 sm:gap-2">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                            stage.done
                              ? 'bg-[#6D8B74] text-white shadow-sm'
                              : 'bg-[#FAF6F0] border border-[#EADFD4] text-[#807571]'
                          }`}
                        >
                          {stage.done ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                        </div>
                        <div>
                          <div className={`text-xs font-semibold ${stage.done ? 'text-[#2C221E]' : 'text-[#807571]'}`}>
                            {stage.label}
                          </div>
                          <div className="text-[11px] text-[#807571] leading-tight mt-0.5">
                            {stage.desc}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Order Items & Counter Pass */}
                <div className="p-6 sm:p-8 grid md:grid-cols-12 gap-8 items-start">
                  
                  {/* Left Column: Line items */}
                  <div className="md:col-span-8 space-y-3">
                    <h4 className="text-xs uppercase tracking-wider font-semibold text-[#807571]">
                      Ordered Artisan Items ({order.items.length})
                    </h4>
                    
                    <div className="space-y-2">
                      {order.items.map((item, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between p-3 rounded-xl bg-[#FAF6F0] border border-[#EADFD4]/60 text-xs"
                        >
                          <div className="flex items-center gap-3">
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="w-10 h-10 rounded object-cover border border-[#EADFD4]"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <span className="font-semibold text-[#2C221E] block">
                                {item.quantity}x {item.product.name}
                              </span>
                              {item.selectedSlicing && (
                                <span className="text-[11px] text-[#807571]">
                                  Slicing: {item.selectedSlicing}
                                </span>
                              )}
                            </div>
                          </div>
                          <span className="font-mono font-bold text-[#2C221E] tabular-nums">
                            ${(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right Column: Counter Pickup Pass */}
                  <div className="md:col-span-4 p-5 bg-[#FAF6F0] rounded-xl border border-[#EADFD4] flex flex-col items-center text-center">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-[#807571] mb-2">
                      Counter Pass
                    </span>

                    {/* Barcode graphic */}
                    <div className="w-full h-12 flex items-center justify-between gap-[2px] bg-white p-2 border border-[#EADFD4] rounded">
                      {[4, 2, 5, 2, 6, 3, 2, 5, 3, 2, 4, 6, 2, 4, 3, 5, 2, 4, 2, 6, 3, 2].map((w, idx) => (
                        <div
                          key={idx}
                          className="h-full bg-[#2C221E]"
                          style={{ width: `${w}px` }}
                        />
                      ))}
                    </div>

                    <span className="text-[10px] font-mono tracking-widest text-[#807571] mt-2 block">
                      {order.orderNumber}
                    </span>

                    <div className="mt-3 text-[11px] text-[#4E4541] flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#C46D1E] shrink-0" />
                      <span>42 Rue des Artisans, Paris 3e</span>
                    </div>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
