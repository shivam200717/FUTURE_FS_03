import React, { useState } from 'react';
import { BakeryProduct, ProductAddon } from '../types/bakery';
import { X, Plus, Minus, Check, Flame, Clock, Sparkles } from 'lucide-react';

interface ProductModalProps {
  product: BakeryProduct | null;
  onClose: () => void;
  onAddToCart: (
    product: BakeryProduct,
    quantity: number,
    slicing?: 'whole' | 'thick' | 'toast',
    addons?: ProductAddon[],
    specialInstructions?: string
  ) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState(1);
  const [selectedSlicing, setSelectedSlicing] = useState<'whole' | 'thick' | 'toast'>('whole');
  const [selectedAddons, setSelectedAddons] = useState<ProductAddon[]>([]);
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [justAdded, setJustAdded] = useState(false);

  const toggleAddon = (addon: ProductAddon) => {
    if (selectedAddons.some((a) => a.id === addon.id)) {
      setSelectedAddons(selectedAddons.filter((a) => a.id !== addon.id));
    } else {
      setSelectedAddons([...selectedAddons, addon]);
    }
  };

  const addonsTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
  const totalPrice = (product.price + addonsTotal) * quantity;

  const handleAddToCart = () => {
    onAddToCart(
      product,
      quantity,
      product.category === 'sourdough' ? selectedSlicing : undefined,
      selectedAddons,
      specialInstructions
    );
    setJustAdded(true);
    setTimeout(() => {
      setJustAdded(false);
      onClose();
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-[#2C221E]/60 backdrop-blur-sm animate-in fade-in">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-2xl border border-[#EADFD4] shadow-bakery-modal overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Dismiss Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-white/90 hover:bg-white text-[#2C221E] hover:text-[#C46D1E] rounded-full border border-[#EADFD4] shadow-sm transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="max-h-[85vh] overflow-y-auto">
          {/* Hero Image */}
          <div className="relative aspect-[16/9] w-full bg-[#F7F3ED] overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
            <div className="absolute bottom-4 left-4 right-4 text-white">
              <span className="text-xs uppercase tracking-wider font-semibold opacity-90">
                {product.frenchName}
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold leading-tight">
                {product.name}
              </h2>
            </div>
          </div>

          {/* Modal Body */}
          <div className="p-6 sm:p-8 space-y-6">
            
            {/* Description & Sensory Notes */}
            <div>
              <p className="text-sm sm:text-base text-[#4E4541] leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Baking Specifications Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-[#FAF6F0] rounded-xl border border-[#EADFD4]">
              {product.fermentationHours > 0 && (
                <div className="flex items-start gap-2.5">
                  <Clock className="w-4 h-4 text-[#C46D1E] mt-0.5 shrink-0" />
                  <div>
                    <div className="text-[11px] font-semibold uppercase text-[#807571]">Fermentation</div>
                    <div className="text-xs font-medium text-[#2C221E]">{product.fermentationHours} Hours Cold Proof</div>
                  </div>
                </div>
              )}

              <div className="flex items-start gap-2.5">
                <Flame className="w-4 h-4 text-[#C46D1E] mt-0.5 shrink-0" />
                <div>
                  <div className="text-[11px] font-semibold uppercase text-[#807571]">Hearth Oven</div>
                  <div className="text-xs font-medium text-[#2C221E]">Refractory Stone 240°C</div>
                </div>
              </div>

              <div className="flex items-start gap-2.5 col-span-2 sm:col-span-1">
                <Sparkles className="w-4 h-4 text-[#6D8B74] mt-0.5 shrink-0" />
                <div>
                  <div className="text-[11px] font-semibold uppercase text-[#807571]">Heritage Grains</div>
                  <div className="text-xs font-medium text-[#2C221E] truncate max-w-[140px]">{product.flourBlend.split(',')[0]}</div>
                </div>
              </div>
            </div>

            {/* Crust & Crumb Profile Breakdown */}
            {(product.crustProfile || product.crumbProfile) && (
              <div className="space-y-3 pt-2 border-t border-[#EADFD4]">
                <h4 className="text-xs uppercase tracking-wider font-semibold text-[#807571]">
                  Artisan Texture &amp; Anatomy
                </h4>
                <div className="grid sm:grid-cols-2 gap-3 text-xs">
                  {product.crustProfile && (
                    <div className="p-3 bg-white rounded-lg border border-[#EADFD4]">
                      <span className="font-semibold text-[#2C221E] block mb-1">Crust Texture</span>
                      <span className="text-[#4E4541] leading-relaxed">{product.crustProfile}</span>
                    </div>
                  )}
                  {product.crumbProfile && (
                    <div className="p-3 bg-white rounded-lg border border-[#EADFD4]">
                      <span className="font-semibold text-[#2C221E] block mb-1">Interior Crumb</span>
                      <span className="text-[#4E4541] leading-relaxed">{product.crumbProfile}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Sourdough Slicing Options (if sourdough) */}
            {product.category === 'sourdough' && (
              <div className="space-y-2 pt-2 border-t border-[#EADFD4]">
                <div className="flex items-center justify-between">
                  <label className="text-xs uppercase tracking-wider font-semibold text-[#807571]">
                    Bakery Slicing Preference
                  </label>
                  <span className="text-xs text-[#807571]">Complimentary</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'whole', label: 'Whole Loaf', desc: 'Retains moisture 5+ days' },
                    { id: 'thick', label: 'Artisan Sliced', desc: '18mm thick rustic slice' },
                    { id: 'toast', label: 'Toast Cut', desc: '12mm standard slice' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSelectedSlicing(opt.id as any)}
                      className={`p-2.5 rounded-lg border text-left cursor-pointer transition-colors ${
                        selectedSlicing === opt.id
                          ? 'border-[#C46D1E] bg-[#C46D1E]/5 text-[#2C221E]'
                          : 'border-[#EADFD4] hover:bg-[#FAF6F0] text-[#4E4541]'
                      }`}
                    >
                      <div className="text-xs font-semibold">{opt.label}</div>
                      <div className="text-[10px] text-[#807571] mt-0.5">{opt.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Artisanal Add-ons */}
            {product.availableAddons && product.availableAddons.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-[#EADFD4]">
                <label className="text-xs uppercase tracking-wider font-semibold text-[#807571]">
                  Recommended Artisan Accompaniments
                </label>
                <div className="space-y-2">
                  {product.availableAddons.map((addon) => {
                    const isChecked = selectedAddons.some((a) => a.id === addon.id);
                    return (
                      <label
                        key={addon.id}
                        onClick={() => toggleAddon(addon)}
                        className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-colors ${
                          isChecked
                            ? 'border-[#C46D1E] bg-[#C46D1E]/5'
                            : 'border-[#EADFD4] hover:bg-[#FAF6F0]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                              isChecked
                                ? 'bg-[#C46D1E] border-[#C46D1E] text-white'
                                : 'border-[#807571] bg-white'
                            }`}
                          >
                            {isChecked && <Check className="w-3 h-3 stroke-3" />}
                          </div>
                          <span className="text-xs font-medium text-[#2C221E]">
                            {addon.name}
                          </span>
                        </div>
                        <span className="text-xs font-mono font-semibold text-[#2C221E] tabular-nums">
                          +${addon.price.toFixed(2)}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Special Baker's Note */}
            <div className="space-y-1.5 pt-2 border-t border-[#EADFD4]">
              <label className="text-xs uppercase tracking-wider font-semibold text-[#807571]">
                Note for the Baker (Optional)
              </label>
              <input
                type="text"
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                placeholder="e.g., Pack in extra unbleached paper, darker bake if available"
                className="w-full px-3 py-2 text-xs bg-white border border-[#EADFD4] rounded-lg focus:outline-none focus:border-[#C46D1E] focus:ring-2 focus:ring-[#C46D1E]/15 text-[#2C221E] placeholder-[#807571]"
              />
            </div>
          </div>

          {/* Sticky Bottom Bar for Purchase */}
          <div className="sticky bottom-0 bg-white/95 backdrop-blur-md p-4 sm:p-6 border-t border-[#EADFD4] flex items-center justify-between gap-4">
            
            {/* Quantity Stepper */}
            <div className="flex items-center border border-[#EADFD4] rounded-lg bg-[#FAF6F0] p-1">
              <button
                type="button"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-1.5 hover:bg-white rounded text-[#2C221E] transition-colors cursor-pointer"
                aria-label="Decrease quantity"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-8 text-center text-sm font-bold font-mono text-[#2C221E] tabular-nums">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity(quantity + 1)}
                className="p-1.5 hover:bg-white rounded text-[#2C221E] transition-colors cursor-pointer"
                aria-label="Increase quantity"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Add to Order Button */}
            <button
              onClick={handleAddToCart}
              className={`flex-1 flex items-center justify-between px-6 py-3 rounded-lg font-semibold text-sm transition-all duration-200 cursor-pointer shadow-bakery ${
                justAdded
                  ? 'bg-[#6D8B74] text-white'
                  : 'bg-[#C46D1E] hover:bg-[#D9822B] active:bg-[#A35515] text-white hover:shadow-bakery-raised'
              }`}
            >
              <span>{justAdded ? 'Added to Order!' : 'Add to Order'}</span>
              <span className="font-mono tabular-nums font-bold">
                ${totalPrice.toFixed(2)}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
