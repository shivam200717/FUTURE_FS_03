import React, { useState } from 'react';
import { ShoppingBag, Menu, X, Clock, CalendarDays, BookOpen, Utensils, ReceiptText } from 'lucide-react';

export type ActiveScreen = 'boutique' | 'menu' | 'oven-schedule' | 'reserve' | 'craft' | 'orders';

interface HeaderProps {
  activeScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
  cartCount: number;
  cartSubtotal: number;
  onOpenCart: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeScreen,
  onNavigate,
  cartCount,
  cartSubtotal,
  onOpenCart,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { id: ActiveScreen; label: string; icon: React.ReactNode }[] = [
    { id: 'boutique', label: 'Boutique', icon: <Utensils className="w-4 h-4" /> },
    { id: 'menu', label: 'Bakery Menu', icon: <Utensils className="w-4 h-4" /> },
    { id: 'oven-schedule', label: 'Oven Schedule', icon: <Clock className="w-4 h-4" /> },
    { id: 'reserve', label: 'Reserve Café', icon: <CalendarDays className="w-4 h-4" /> },
    { id: 'craft', label: 'Our Craft', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'orders', label: 'My Orders', icon: <ReceiptText className="w-4 h-4" /> },
  ];

  const handleNavClick = (screen: ActiveScreen) => {
    onNavigate(screen);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#FAF6F0]/95 backdrop-blur-md border-b border-[#EADFD4] transition-all">
        {/* Top Bar Contract: Zone 1 (Brand) — Zone 2 (4-5 Nav Links) — Zone 3 (1 Primary Action) */}
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
          
          {/* Zone 1: Single text element wordmark in display face */}
          <button
            onClick={() => handleNavClick('boutique')}
            className="text-left group cursor-pointer focus:outline-none"
          >
            <span className="font-serif text-2xl sm:text-3xl font-semibold tracking-tight text-[#2C221E] group-hover:text-[#C46D1E] transition-colors whitespace-nowrap shrink-0">
              Maison Marcel
            </span>
          </button>

          {/* Zone 2: Single-line clean text navigation links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#4E4541]">
            {navLinks.map((link) => {
              const isActive = activeScreen === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`relative py-1 cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'text-[#2C221E] font-semibold'
                      : 'text-[#4E4541] hover:text-[#2C221E]'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C46D1E] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action (Cart Drawer Trigger) */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenCart}
              className="relative flex items-center gap-2.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-[#C46D1E] hover:bg-[#D9822B] active:bg-[#A35515] rounded-lg shadow-bakery-sm hover:shadow-bakery transition-all transform hover:-translate-y-0.5 cursor-pointer whitespace-nowrap shrink-0"
              aria-label={`Shopping bag with ${cartCount} items`}
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              <span>Bag</span>
              {cartCount > 0 ? (
                <>
                  <span className="bg-[#2C221E] text-white text-[11px] font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center tabular-nums">
                    {cartCount}
                  </span>
                  <span className="hidden sm:inline border-l border-white/30 pl-2 text-xs font-mono tabular-nums">
                    ${cartSubtotal.toFixed(2)}
                  </span>
                </>
              ) : (
                <span className="text-[11px] opacity-80">(0)</span>
              )}
            </button>

            {/* Mobile menu hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#2C221E] hover:text-[#C46D1E] hover:bg-white rounded-lg transition-colors border border-[#EADFD4]"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-30 bg-[#2C221E]/40 backdrop-blur-sm animate-in fade-in">
          <div className="absolute top-20 left-0 right-0 bg-[#FAF6F0] border-b border-[#EADFD4] p-6 shadow-bakery-modal flex flex-col gap-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#807571] mb-2">
              Navigation
            </div>
            {navLinks.map((link) => {
              const isActive = activeScreen === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg text-base font-medium text-left transition-colors ${
                    isActive
                      ? 'bg-white text-[#C46D1E] shadow-bakery-sm border border-[#EADFD4]'
                      : 'text-[#2C221E] hover:bg-white/60'
                  }`}
                >
                  <span className={isActive ? 'text-[#C46D1E]' : 'text-[#807571]'}>
                    {link.icon}
                  </span>
                  <span>{link.label}</span>
                </button>
              );
            })}
            <div className="pt-4 border-t border-[#EADFD4] mt-2 flex items-center justify-between text-xs text-[#807571]">
              <span>Maison Marcel Boulangerie</span>
              <span>Open Daily: 06:30 – 17:00</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
