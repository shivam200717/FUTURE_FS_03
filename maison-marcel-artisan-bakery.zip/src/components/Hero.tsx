import React from 'react';
import { ArrowRight, Clock, Award, Sparkles, Flame } from 'lucide-react';
import { ActiveScreen } from './Header';

interface HeroProps {
  onNavigate: (screen: ActiveScreen) => void;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:py-20 border-b border-[#EADFD4]/60">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Split Grid: Left Content (Editorial Typography) / Right Imagery (Artisan Hearth & Sourdough) */}
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left 7 Columns: Editorial Text Stack */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6">
            
            {/* Live Oven Batch Kicker (No Pill Sandwich, clean unboxed metadata with dot separators) */}
            <div className="flex items-center gap-2 text-xs font-semibold text-[#934B00] tracking-wide">
              <span className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-[#C46D1E]" />
                Morning Bake Active
              </span>
              <span aria-hidden="true" className="text-[#D2C4BF]">·</span>
              <span className="text-[#4E4541]">08:00 AM Hearth Batch Fresh on Marble</span>
            </div>

            {/* Display Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#2C221E] leading-[1.12] text-balance">
              Naturally Fermented Sourdough &amp; Morning Viennoiserie.
            </h1>

            {/* Prose Body */}
            <p className="text-base sm:text-lg text-[#4E4541] font-normal leading-relaxed max-w-xl">
              Shaped by hand before dawn from heritage stoneground French wheat, pure Normandy cultured butter, and our century-old levain starter <em className="italic font-serif">Émile</em>. Baked daily in refractory stone hearths.
            </p>

            {/* Interactive Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('menu')}
                className="flex items-center gap-2 px-6 py-3.5 bg-[#C46D1E] hover:bg-[#D9822B] active:bg-[#A35515] text-white rounded-lg font-semibold text-sm shadow-bakery hover:shadow-bakery-raised transition-all transform hover:-translate-y-0.5 cursor-pointer whitespace-nowrap shrink-0 group"
              >
                <span>Order Ahead for Pickup</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => onNavigate('oven-schedule')}
                className="flex items-center gap-2 px-5 py-3.5 bg-white border border-[#2C221E] text-[#2C221E] hover:bg-[#FAF6F0] rounded-lg font-semibold text-sm transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Clock className="w-4 h-4 text-[#C46D1E]" />
                <span>Live Oven Schedule</span>
              </button>

              <button
                onClick={() => onNavigate('reserve')}
                className="text-xs font-semibold text-[#807571] hover:text-[#2C221E] underline underline-offset-4 px-2 py-2 cursor-pointer transition-colors"
              >
                Reserve a Café Table &rarr;
              </button>
            </div>

            {/* Social Proof & Quantitative Adjacency */}
            <div className="pt-6 border-t border-[#EADFD4] w-full flex flex-wrap items-center gap-y-3 gap-x-8 text-xs text-[#807571]">
              <div className="flex items-center gap-2">
                <span className="text-[#C46D1E] font-bold">4.9 ★</span>
                <span className="font-medium text-[#2C221E]">840+ Neighborhood Reviews</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#6D8B74]" />
                <span>36-Hour Natural Cold Levain</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#C46D1E]" />
                <span>100% Unbleached French Flour</span>
              </div>
            </div>

          </div>

          {/* Right 5 Columns: Visual Bakery Gallery Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#EADFD4] shadow-bakery-raised bg-white p-2">
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-[#F7F3ED]">
                <img
                  src="https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1000&q=80"
                  alt="Fresh artisan sourdough batards out of the oven at Maison Marcel"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent pointer-events-none" />
                
                {/* Floating Caption on Image */}
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-amber-300">
                    Boulangerie Tradition
                  </div>
                  <h3 className="font-serif text-lg font-bold">
                    Pain de Campagne au Levain
                  </h3>
                  <p className="text-xs text-stone-200 mt-0.5">
                    82% Hydration · Blistered Mahogany Crust · Wild Open Crumb
                  </p>
                </div>
              </div>

              {/* Mini Under-card highlights */}
              <div className="grid grid-cols-3 gap-2 pt-3 px-1 text-center">
                <div className="p-2 bg-[#FAF6F0] rounded-lg border border-[#EADFD4]/60">
                  <div className="font-serif text-base font-bold text-[#2C221E]">06:30</div>
                  <div className="text-[10px] text-[#807571] uppercase tracking-wide">First Pull</div>
                </div>
                <div className="p-2 bg-[#FAF6F0] rounded-lg border border-[#EADFD4]/60">
                  <div className="font-serif text-base font-bold text-[#2C221E]">240°C</div>
                  <div className="text-[10px] text-[#807571] uppercase tracking-wide">Stone Deck</div>
                </div>
                <div className="p-2 bg-[#FAF6F0] rounded-lg border border-[#EADFD4]/60">
                  <div className="font-serif text-base font-bold text-[#2C221E]">1928</div>
                  <div className="text-[10px] text-[#807571] uppercase tracking-wide">Émile Starter</div>
                </div>
              </div>
            </div>

            {/* Decorative Organic Wheat Stamp */}
            <div className="hidden sm:block absolute -bottom-5 -left-5 bg-white border border-[#EADFD4] rounded-full p-3 shadow-bakery text-[#C46D1E]">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
