import React, { useState } from 'react';
import { CartItem, OrderRecord } from '../types/bakery';
import { X, Check, ShieldCheck, MapPin, Bike, Store, CreditCard, Smartphone, DollarSign, Download, ArrowRight } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  subtotal: number;
  discount: number;
  pickupSlot: string;
  onOrderCompleted: (order: OrderRecord) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  subtotal,
  discount,
  pickupSlot,
  onOrderCompleted,
}) => {
  if (!isOpen) return null;

  const [fulfillmentType, setFulfillmentType] = useState<'pickup' | 'delivery'>('pickup');
  const [customerName, setCustomerName] = useState('Claire Delacroix');
  const [customerEmail, setCustomerEmail] = useState('claire.delacroix@example.com');
  const [customerPhone, setCustomerPhone] = useState('+33 6 42 18 90 22');
  const [deliveryAddress, setDeliveryAddress] = useState('18 Rue de Turenne, 3rd Arrondissement');
  const [paymentMethod, setPaymentMethod] = useState<'apple_pay' | 'card' | 'counter'>('apple_pay');
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvc, setCardCvc] = useState('882');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<OrderRecord | null>(null);

  const deliveryFee = fulfillmentType === 'delivery' ? 3.50 : 0.00;
  const taxableAmount = Math.max(0, subtotal - discount);
  const tax = taxableAmount * 0.0825;
  const grandTotal = taxableAmount + tax + deliveryFee;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const newOrder: OrderRecord = {
        id: `ord_${Date.now()}`,
        orderNumber: `MM-${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        pickupTime: pickupSlot,
        items: [...items],
        subtotal,
        discount,
        tax,
        total: grandTotal,
        customerName,
        customerPhone,
        customerEmail,
        fulfillmentType,
        deliveryAddress: fulfillmentType === 'delivery' ? deliveryAddress : undefined,
        paymentMethod,
        status: 'in_oven',
      };

      setCompletedOrder(newOrder);
      setIsSubmitting(false);
      onOrderCompleted(newOrder);
    }, 900);
  };

  const handleDownloadReceipt = () => {
    if (!completedOrder) return;
    const receiptContent = `
=============================================
         MAISON MARCEL ARTISAN BAKERY
       42 Rue des Artisans, Paris 3e
=============================================
Order: ${completedOrder.orderNumber}
Date: ${new Date().toLocaleDateString()} at ${completedOrder.createdAt}
Customer: ${completedOrder.customerName}
Fulfillment: ${completedOrder.fulfillmentType.toUpperCase()}
Scheduled Window: ${completedOrder.pickupTime}
---------------------------------------------
ITEMS:
${completedOrder.items
  .map(
    (i) =>
      `${i.quantity}x ${i.product.name} - $${(i.product.price * i.quantity).toFixed(2)}${
        i.selectedSlicing ? ` [${i.selectedSlicing}]` : ''
      }`
  )
  .join('\n')}
---------------------------------------------
Subtotal: $${completedOrder.subtotal.toFixed(2)}
Discount: -$${completedOrder.discount.toFixed(2)}
Tax (8.25%): $${completedOrder.tax.toFixed(2)}
Fulfillment Fee: $${deliveryFee.toFixed(2)}
TOTAL: $${completedOrder.total.toFixed(2)}
---------------------------------------------
Payment Method: ${completedOrder.paymentMethod.replace('_', ' ').toUpperCase()}
Payment Status: VERIFIED
=============================================
   Merci pour votre confiance & bon appétit!
    `;
    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MaisonMarcel_Receipt_${completedOrder.orderNumber}.txt`;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-[#2C221E]/60 backdrop-blur-sm animate-in fade-in">
      <div 
        className="relative w-full max-w-xl bg-white rounded-2xl border border-[#EADFD4] shadow-bakery-modal overflow-hidden my-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 bg-[#FAF6F0] border-b border-[#EADFD4] flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C46D1E]">
              Artisan Boulangerie
            </span>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#2C221E]">
              {completedOrder ? 'Order Confirmed & Baking' : 'Artisan Order Checkout'}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#807571] hover:text-[#2C221E] rounded-lg hover:bg-white transition-colors cursor-pointer"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 sm:p-8 max-h-[80vh] overflow-y-auto">
          {completedOrder ? (
            /* Order Completed Success View */
            <div className="space-y-6 text-center animate-in zoom-in-95">
              <div className="w-16 h-16 rounded-full bg-[#6D8B74]/15 border border-[#6D8B74]/30 flex items-center justify-center mx-auto text-[#3B5241]">
                <Check className="w-8 h-8 stroke-3" />
              </div>

              <div>
                <span className="text-xs uppercase tracking-widest text-[#807571] font-semibold">
                  Bake Order Verified
                </span>
                <h3 className="font-serif text-3xl font-bold text-[#2C221E] mt-1">
                  {completedOrder.orderNumber}
                </h3>
                <p className="text-xs text-[#807571] mt-1.5 max-w-sm mx-auto">
                  Merci, {completedOrder.customerName}! Your morning loaves and pastries are assigned to our hearth baking queue.
                </p>
              </div>

              {/* Simulated Barcode for Counter Pickup */}
              <div className="p-4 bg-[#FAF6F0] border border-[#EADFD4] rounded-xl flex flex-col items-center">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-[#807571] mb-2">
                  Counter Pickup Pass
                </span>
                
                {/* SVG Barcode Pattern */}
                <div className="w-48 h-12 flex items-center justify-between gap-[2px] bg-white p-2 border border-[#EADFD4] rounded">
                  {[4, 2, 5, 2, 6, 3, 2, 5, 3, 2, 4, 6, 2, 4, 3, 5, 2, 4, 2, 6, 3, 2].map((w, idx) => (
                    <div
                      key={idx}
                      className="h-full bg-[#2C221E]"
                      style={{ width: `${w}px` }}
                    />
                  ))}
                </div>
                <span className="text-[10px] font-mono tracking-widest text-[#807571] mt-1.5">
                  {completedOrder.orderNumber} · SCAN AT MARBLE COUNTER
                </span>
              </div>

              {/* Order Details Strip */}
              <div className="grid grid-cols-2 gap-3 text-left text-xs bg-white p-4 rounded-xl border border-[#EADFD4]">
                <div>
                  <span className="text-[#807571] block">Fulfillment Window</span>
                  <span className="font-semibold text-[#2C221E] mt-0.5 block">
                    {completedOrder.pickupTime}
                  </span>
                </div>
                <div>
                  <span className="text-[#807571] block">Location</span>
                  <span className="font-semibold text-[#2C221E] mt-0.5 block">
                    {completedOrder.fulfillmentType === 'pickup'
                      ? '42 Rue des Artisans, Paris'
                      : completedOrder.deliveryAddress}
                  </span>
                </div>
                <div className="col-span-2 pt-2 border-t border-[#EADFD4] flex justify-between">
                  <span className="text-[#807571]">Total Paid ({completedOrder.paymentMethod.replace('_', ' ')})</span>
                  <span className="font-mono font-bold text-[#C46D1E] tabular-nums">
                    ${completedOrder.total.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleDownloadReceipt}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-[#2C221E] text-[#2C221E] hover:bg-[#FAF6F0] rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Digital Receipt</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 px-4 py-2.5 bg-[#C46D1E] hover:bg-[#D9822B] text-white rounded-xl text-xs font-semibold shadow-bakery-sm transition-colors cursor-pointer"
                >
                  Done &amp; Return to Boutique
                </button>
              </div>
            </div>
          ) : (
            /* Checkout Form View */
            <form onSubmit={handleSubmitOrder} className="space-y-6">
              
              {/* Fulfillment Method Selector */}
              <div>
                <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block mb-2">
                  1. Fulfillment Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFulfillmentType('pickup')}
                    className={`p-3.5 rounded-xl border text-left flex items-start gap-3 cursor-pointer transition-colors ${
                      fulfillmentType === 'pickup'
                        ? 'border-[#C46D1E] bg-[#C46D1E]/5 text-[#2C221E]'
                        : 'border-[#EADFD4] hover:bg-[#FAF6F0] text-[#4E4541]'
                    }`}
                  >
                    <Store className={`w-5 h-5 shrink-0 mt-0.5 ${fulfillmentType === 'pickup' ? 'text-[#C46D1E]' : 'text-[#807571]'}`} />
                    <div>
                      <div className="text-xs font-bold">Bakery Counter Pickup</div>
                      <div className="text-[11px] text-[#807571] mt-0.5">Free · Hot from Hearth</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFulfillmentType('delivery')}
                    className={`p-3.5 rounded-xl border text-left flex items-start gap-3 cursor-pointer transition-colors ${
                      fulfillmentType === 'delivery'
                        ? 'border-[#C46D1E] bg-[#C46D1E]/5 text-[#2C221E]'
                        : 'border-[#EADFD4] hover:bg-[#FAF6F0] text-[#4E4541]'
                    }`}
                  >
                    <Bike className={`w-5 h-5 shrink-0 mt-0.5 ${fulfillmentType === 'delivery' ? 'text-[#C46D1E]' : 'text-[#807571]'}`} />
                    <div>
                      <div className="text-xs font-bold">Eco-Bike Courier</div>
                      <div className="text-[11px] text-[#807571] mt-0.5">+$3.50 · Insulated Basket</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Customer Contact Details */}
              <div className="space-y-3">
                <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block">
                  2. Contact &amp; Notification
                </label>
                
                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] font-medium text-[#4E4541] block mb-1">Full Name</span>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] font-medium text-[#4E4541] block mb-1">Mobile Phone (Bake SMS)</span>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                    />
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-medium text-[#4E4541] block mb-1">Email (Digital Receipt)</span>
                  <input
                    type="email"
                    required
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-white border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                  />
                </div>

                {fulfillmentType === 'delivery' && (
                  <div>
                    <span className="text-[11px] font-medium text-[#4E4541] block mb-1">Delivery Address</span>
                    <div className="relative">
                      <MapPin className="w-4 h-4 text-[#807571] absolute left-3 top-2.5" />
                      <input
                        type="text"
                        required
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        placeholder="Street, Building, Floor & Code"
                        className="w-full text-xs pl-9 pr-3 py-2 bg-white border border-[#EADFD4] rounded-lg text-[#2C221E] focus:outline-none focus:border-[#C46D1E]"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Payment Method */}
              <div className="space-y-3">
                <label className="text-xs uppercase tracking-wider font-semibold text-[#807571] block">
                  3. Payment Method
                </label>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('apple_pay')}
                    className={`p-3 rounded-lg border text-center cursor-pointer transition-colors ${
                      paymentMethod === 'apple_pay'
                        ? 'border-[#C46D1E] bg-[#C46D1E]/5 text-[#2C221E]'
                        : 'border-[#EADFD4] hover:bg-[#FAF6F0] text-[#4E4541]'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 mx-auto mb-1 text-[#2C221E]" />
                    <span className="text-xs font-semibold block">Pay Pass</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-3 rounded-lg border text-center cursor-pointer transition-colors ${
                      paymentMethod === 'card'
                        ? 'border-[#C46D1E] bg-[#C46D1E]/5 text-[#2C221E]'
                        : 'border-[#EADFD4] hover:bg-[#FAF6F0] text-[#4E4541]'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 mx-auto mb-1 text-[#2C221E]" />
                    <span className="text-xs font-semibold block">Credit Card</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('counter')}
                    className={`p-3 rounded-lg border text-center cursor-pointer transition-colors ${
                      paymentMethod === 'counter'
                        ? 'border-[#C46D1E] bg-[#C46D1E]/5 text-[#2C221E]'
                        : 'border-[#EADFD4] hover:bg-[#FAF6F0] text-[#4E4541]'
                    }`}
                  >
                    <DollarSign className="w-4 h-4 mx-auto mb-1 text-[#2C221E]" />
                    <span className="text-xs font-semibold block">At Counter</span>
                  </button>
                </div>

                {paymentMethod === 'card' && (
                  <div className="p-3.5 bg-[#FAF6F0] rounded-xl border border-[#EADFD4] space-y-2.5">
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-[#807571] block mb-1">Card Number</span>
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-white border border-[#EADFD4] rounded-lg font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[10px] uppercase font-semibold text-[#807571] block mb-1">Expires</span>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-white border border-[#EADFD4] rounded-lg font-mono text-center"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-semibold text-[#807571] block mb-1">CVC</span>
                        <input
                          type="text"
                          value={cardCvc}
                          onChange={(e) => setCardCvc(e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-white border border-[#EADFD4] rounded-lg font-mono text-center"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Order Breakdown */}
              <div className="p-4 bg-[#FAF6F0] rounded-xl border border-[#EADFD4] text-xs space-y-1.5">
                <div className="flex justify-between text-[#807571]">
                  <span>Items Subtotal</span>
                  <span className="font-mono tabular-nums">${subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-[#6D8B74] font-medium">
                    <span>Privilege Discount</span>
                    <span className="font-mono tabular-nums">-${discount.toFixed(2)}</span>
                  </div>
                )}
                {fulfillmentType === 'delivery' && (
                  <div className="flex justify-between text-[#807571]">
                    <span>Eco-Bike Delivery</span>
                    <span className="font-mono tabular-nums">$3.50</span>
                  </div>
                )}
                <div className="flex justify-between text-[#807571]">
                  <span>Estimated Tax</span>
                  <span className="font-mono tabular-nums">${tax.toFixed(2)}</span>
                </div>
                <div className="pt-2 border-t border-[#EADFD4] flex justify-between items-baseline text-sm font-bold text-[#2C221E]">
                  <span>Total Amount</span>
                  <span className="font-mono text-base text-[#C46D1E] tabular-nums">
                    ${grandTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-[#C46D1E] hover:bg-[#D9822B] active:bg-[#A35515] disabled:opacity-50 text-white rounded-xl font-semibold text-sm shadow-bakery cursor-pointer transition-all"
              >
                {isSubmitting ? (
                  <span>Transmitting to Hearth Bakery...</span>
                ) : (
                  <>
                    <span>Confirm &amp; Place Order (${grandTotal.toFixed(2)})</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-[#807571]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#6D8B74]" />
                <span>Encrypted 256-bit culinary transaction · Freshness guaranteed</span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
