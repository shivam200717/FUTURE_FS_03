export type BakeryCategory = 
  | 'all'
  | 'sourdough'
  | 'pastries'
  | 'savory'
  | 'coffee'
  | 'pantry';

export interface ProductAddon {
  id: string;
  name: string;
  price: number;
}

export interface BakeryProduct {
  id: string;
  name: string;
  frenchName: string;
  category: 'sourdough' | 'pastries' | 'savory' | 'coffee' | 'pantry';
  price: number;
  description: string;
  tastingNotes: string[];
  flourBlend: string;
  fermentationHours: number;
  dietaryTags: string[];
  image: string;
  isPopular?: boolean;
  isMorningSpecial?: boolean;
  crustProfile?: string;
  crumbProfile?: string;
  pairingRecommendation?: string;
  storageTip?: string;
  availableAddons?: ProductAddon[];
}

export interface CartItem {
  product: BakeryProduct;
  quantity: number;
  selectedSlicing?: 'whole' | 'thick' | 'toast';
  selectedAddons?: ProductAddon[];
  specialInstructions?: string;
}

export interface OvenBatch {
  id: string;
  timeSlot: string;
  productName: string;
  frenchName: string;
  status: 'baking' | 'cooling' | 'ready' | 'proofing' | 'upcoming';
  progressPercent: number;
  tempCelsius: number;
  unitsBatch: number;
  flourOrigin: string;
}

export interface ReservationRequest {
  id?: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  seatingArea: 'solarium' | 'main-hall' | 'garden-terrace';
  specialNotes?: string;
}

export interface OrderRecord {
  id: string;
  orderNumber: string;
  createdAt: string;
  pickupTime: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  fulfillmentType: 'pickup' | 'delivery';
  deliveryAddress?: string;
  paymentMethod: 'apple_pay' | 'card' | 'counter';
  status: 'received' | 'in_oven' | 'packaging' | 'ready_for_pickup' | 'completed';
}
