---
name: Maison Marcel Artisan Bakery
colors:
  surface: '#fdf9f3'
  surface-dim: '#dddad4'
  surface-bright: '#fdf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3ed'
  surface-container: '#f1ede7'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e6e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#4e4541'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f4f0ea'
  outline: '#807571'
  outline-variant: '#d2c4bf'
  surface-tint: '#695c57'
  primary: '#150d0a'
  on-primary: '#ffffff'
  primary-container: '#2c221e'
  on-primary-container: '#978883'
  inverse-primary: '#d4c3bd'
  secondary: '#934b00'
  on-secondary: '#ffffff'
  secondary-container: '#fe9b4a'
  on-secondary-container: '#6e3700'
  tertiary: '#001206'
  on-tertiary: '#ffffff'
  tertiary-container: '#0d2918'
  on-tertiary-container: '#74927b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f1dfd8'
  primary-fixed-dim: '#d4c3bd'
  on-primary-fixed: '#231916'
  on-primary-fixed-variant: '#504440'
  secondary-fixed: '#ffdcc5'
  secondary-fixed-dim: '#ffb782'
  on-secondary-fixed: '#301400'
  on-secondary-fixed-variant: '#703800'
  tertiary-fixed: '#caebd0'
  tertiary-fixed-dim: '#aeceb5'
  on-tertiary-fixed: '#042010'
  on-tertiary-fixed-variant: '#314d39'
  background: '#fdf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e6e2dc'
typography:
  display:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

This design system crafts an authentic, sensory digital presence for an artisanal neighborhood bakery and specialty café. The aesthetic strikes a thoughtful balance between old-world French craft and contemporary boutique hospitality. 

### Emotional Persona & Aesthetic
- **Character:** Warm, grounded, artisanal, sensory, and quietly prestigious.
- **Target Audience:** Connoisseurs of sourdough bread, morning café locals, design-conscious urban foodies, and customers seeking elevated everyday rituals.
- **Emotional Response:** Comfort, morning anticipation, culinary trust, tactile warmth, and relaxed luxury.

### Design Movement
**Warm Editorial Minimalist with Tactile Organic Nuances.** The visual system rejects clinical tech tropes, relying instead on warm editorial layouts, generous linen-like negative space, rich natural espresso tones, and delicate tactile borders that resemble artisan paper and bakery parchment. Micro-interactions are deliberate and smooth, evoking the slow craftsmanship of naturally fermented sourdough.

## Colors

The palette is derived from natural organic baking ingredients: slow-roasted coffee beans, blistered golden-crusted sourdough, unbleached flour, stone tiles, and dried culinary herbs.

### Role Assignments
- **Canvas Base (`#FAF6F0`):** Buttery cream foundation that removes screen glare, providing the tactile comfort of stone countertops and fresh butcher paper.
- **Primary / Typography (`#2C221E`):** Deep roasted espresso slate. Used for all primary headlines, sharp body text, high-emphasis icons, and structural dividers. Never substitute pure `#000000`.
- **Secondary (`#C46D1E`):** Golden roasted honey amber. Applied to primary calls-to-action, seasonal specials, active states, and bakery craft highlights. An energetic tint (`#D9822B`) is reserved for hover highlights and badge accents.
- **Tertiary (`#6D8B74`):** Soft sage herbal wash. Reserved for dietary badges (vegan, organic, naturally leavened), herb-infused bakery items, freshness guarantees, and soft status pills.
- **Surface Elevation (`#FFFFFF`):** Pure flour white, utilized strictly for elevated cards, item trays, and modal sheets to introduce contrast and clean focal framing against the cream background.
- **Border / Hairline (`#EADFD4`):** Subtle unbleached linen tone used for fine structural separations without harsh visual weight.

## Typography

Typography establishes an editorial atmosphere reminiscent of French food anthologies and boutique lifestyle journals.

### Pairing Logic
- **Playfair Display (Serif):** Expressive, stately, and steeped in gastronomic tradition. Applied to master headings, hero copy, menu category titles, and culinary quotes.
- **Plus Jakarta Sans (Sans-serif):** Balanced, modern, and open, balancing the expressive character of the serif with exceptional readability for ingredient lists, nutritional badges, item descriptions, and ordering interfaces.

### Application Guidelines
- All display and large headline levels adopt optical kerning with slight negative tracking to preserve rhythm.
- Uppercase text is strictly reserved for `label-sm` and `label-md` micro-badges (such as origin notes, bakery batches, and dietary tags) and must consistently feature positive letter spacing (`0.05em` to `0.08em`).

## Layout & Spacing

The layout model utilizes a structured, high-breathability grid with generous margins to honor culinary presentation and reduce visual noise.

### Grid & Composition
- **Desktop (12 Columns):** Fixed max-width of `1280px` centered within the viewport. Outer margin of `3rem` (`space-xl` + `space-md`), gutter width of `1.5rem`.
- **Tablet (8 Columns):** Fluid grid with `2rem` outer margins and `1.25rem` gutters.
- **Mobile (4 Columns):** Fluid vertical flow with `1.25rem` canvas margin and `1rem` column gutters.

### Rhythm & Density
Whitespace is treated as a premium design asset. Menus, item cards, and ingredient breakdowns are given room to breathe using `space-lg` and `space-xl` element gaps, mimicking an uncluttered café table.

## Elevation & Depth

Rather than relying on sterile, synthetic drop shadows, this design system uses soft, organic ambient light layered over buttery canvas tones.

### Ambient Shadow Strategy
- **Base Level (Canvas):** Tone `#FAF6F0` operates as the grounded floor plan.
- **Level 1 (Card & Tray Surface):** Pure `#FFFFFF` surfaces sit on the canvas with a soft honey-tinted ambient shadow:
  - `box-shadow: 0 4px 20px -2px rgba(44, 34, 30, 0.04), 0 2px 6px -1px rgba(44, 34, 30, 0.02);`
  - Encased with a delicate hairline border: `1px solid #EADFD4`.
- **Level 2 (Active & Floating Menus / Popovers):** Raised interactive layers capture slightly deeper ambient espresso falloff:
  - `box-shadow: 0 12px 32px -4px rgba(44, 34, 30, 0.08), 0 4px 12px -2px rgba(44, 34, 30, 0.04);`
- **Level 3 (Modal Dialogs & Cart Drawers):** Backdrop overlay uses rich espresso `#2C221E` at `40% opacity` with `4px` backdrop blur, anchoring focused attention without cold dark-mode aesthetics.

## Shapes

The shape system employs roundedness level **2 (Rounded)** to reflect the hand-shaped, organic contours of proofed sourdough loaves, pastry curves, and ceramic café ware.

### Geometry Specifications
- **Cards, Trays & Sheets:** `1rem` (`rounded-lg`) border radius for gentle, tactile boundaries.
- **Action Buttons & Inputs:** `0.5rem` (`rounded`) for confident interactive targets.
- **Trust Badges, Status Pills & Tags:** Full pill format (`9999px`) to maintain contrast with square media containers.
- **Images & Photography Assets:** `0.75rem` to `1rem` with inner border outlines to evoke gallery framing.

## Components

### Buttons
- **Primary:** Solid `#C46D1E` background, `#FFFFFF` text, `0.5rem` radius, `label-lg` typography. Subtle lift and color transition to `#D9822B` on hover with a warm shadow.
- **Secondary / Craft Action:** Deep Espresso `#2C221E` solid background, `#FAF6F0` text. Applied to checkout flows and reservation completions.
- **Outline / Editorial:** Transparent background, `1.5px` solid `#2C221E` border, `#2C221E` text. Fills with `#FAF6F0` on hover.

### Food & Product Cards
- Built on pure white `#FFFFFF` surfaces with `rounded-lg` corners and fine `#EADFD4` borders.
- Aspect ratio of 4:3 or 1:1 for hero bakery photography, treated with warm color temperature and clean framing.
- Content stack: Category pill (e.g., "Naturally Leavened 36H"), Playfair Display title, brief tasting notes in `body-sm`, price in bold `Plus Jakarta Sans`, and a compact "+ Add" rounded button.

### Badges & Micro-Pills
- **Dietary & Freshness Tags:** Herbal sage `#6D8B74` background at 15% opacity with dark sage `#3B5241` text.
- **Honey Special Badges:** `#C46D1E` background at 12% opacity with `#8A4A0F` text.
- **Local Credibility Badge (e.g., Google 4.9 Rating):** Crisp `#FFFFFF` capsule pill, containing an amber star icon, espresso text "4.9 ★ (840+ reviews)", bordered by `#EADFD4`.

### Input Fields & Selectors
- Background: `#FFFFFF`.
- Border: `1.5px solid #EADFD4`.
- Focus state: Border transitions to `#C46D1E` with a faint `3px` ambient ring in `rgba(196, 109, 30, 0.15)`.
- Placeholder: `#8F8179` in `body-md`.

### Lists & Menu Groups
- Editorial row dividers use `1px solid #EADFD4`.
- Menu item titles in serif `headline-sm`, trailing price in `title-md`, and detailed ingredients running beneath in soft espresso `body-sm`.
- Subtle right-aligned dot-leaders or clean whitespace separation.

### Checkboxes & Radio Buttons
- Checkbox squares and radio circles feature `1.5px solid #8F8179` borders on `#FFFFFF` backgrounds.
- Active state fills with `#C46D1E` and an unbleached `#FFFFFF` checkmark or center pip.